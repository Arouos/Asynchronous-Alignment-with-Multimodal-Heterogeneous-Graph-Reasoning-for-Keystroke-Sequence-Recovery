# Device detection and tensor placement helpers.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch


def resolve_device(name: str | None = None) -> torch.device:
    """Resolve the requested device string, falling back to CPU when needed."""
    if name in (None, "auto"):
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if name == "cuda" and not torch.cuda.is_available():
        return torch.device("cpu")
    return torch.device(name)


def to_device(batch: Any, device: torch.device) -> Any:
    """Move tensors, dictionaries or lists of tensors to ``device``."""
    if isinstance(batch, torch.Tensor):
        return batch.to(device, non_blocking=True)
    if isinstance(batch, dict):
        return {key: to_device(value, device) for key, value in batch.items()}
    if isinstance(batch, (list, tuple)):
        moved = [to_device(item, device) for item in batch]
        return type(batch)(moved)
    return batch
