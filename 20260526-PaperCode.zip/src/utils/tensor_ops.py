# Tensor utilities shared across model components.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch
import torch.nn.functional as F


def segment_softmax(values: torch.Tensor, segment_ids: torch.Tensor, num_segments: int) -> torch.Tensor:
    """Apply a numerically stable softmax within each segment.

    ``values`` has shape ``[N]`` and ``segment_ids`` maps each entry to a segment.
    """
    max_per_segment = torch.full((num_segments,), float("-inf"), device=values.device, dtype=values.dtype)
    max_per_segment = max_per_segment.scatter_reduce(0, segment_ids, values, reduce="amax", include_self=True)
    shifted = values - max_per_segment[segment_ids]
    exp_values = shifted.exp()
    denom = torch.zeros(num_segments, device=values.device, dtype=values.dtype).scatter_add(0, segment_ids, exp_values)
    return exp_values / (denom[segment_ids] + 1e-12)


def topk_per_row(logits: torch.Tensor, k: int) -> tuple[torch.Tensor, torch.Tensor]:
    """Return top-k values and indices per row, clamping ``k`` by row length."""
    k_eff = min(k, logits.size(-1))
    return logits.topk(k_eff, dim=-1)


def masked_mean(values: torch.Tensor, mask: torch.Tensor, dim: int = -1) -> torch.Tensor:
    """Compute the mean of ``values`` over a binary ``mask`` along ``dim``."""
    weights = mask.to(values.dtype)
    denom = weights.sum(dim=dim).clamp(min=1.0)
    return (values * weights).sum(dim=dim) / denom


def safe_log(x: torch.Tensor, eps: float = 1e-12) -> torch.Tensor:
    """Numerically safe logarithm."""
    return torch.log(x.clamp(min=eps))


def gumbel_sigmoid(logits: torch.Tensor, temperature: float = 1.0, hard: bool = False) -> torch.Tensor:
    """Gumbel-sigmoid relaxation for differentiable edge gating."""
    noise = -torch.empty_like(logits).exponential_().log()
    noise2 = -torch.empty_like(logits).exponential_().log()
    soft = torch.sigmoid((logits + noise - noise2) / temperature)
    if not hard:
        return soft
    hard_mask = (soft > 0.5).to(soft.dtype)
    return hard_mask + (soft - soft.detach())
