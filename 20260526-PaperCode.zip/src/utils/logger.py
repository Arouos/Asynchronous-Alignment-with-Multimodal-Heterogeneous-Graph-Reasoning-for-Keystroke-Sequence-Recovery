# Logging helper that mirrors records to file and console.
# Author: Haoyu Qiang.

from __future__ import annotations

import logging
from pathlib import Path


def build_logger(name: str, log_dir: str | Path | None = None, level: str = "INFO") -> logging.Logger:
    """Construct a logger with consistent format across the project."""
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    logger.handlers.clear()

    formatter = logging.Formatter("[%(asctime)s][%(name)s][%(levelname)s] %(message)s")

    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    logger.addHandler(stream)

    if log_dir is not None:
        log_dir = Path(log_dir)
        log_dir.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_dir / f"{name}.log", encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    logger.propagate = False
    return logger
