# YAML configuration loader with shallow merge support.
# Author: Haoyu Qiang.

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping

import yaml


def load_yaml(path: str | Path) -> dict[str, Any]:
    """Read a YAML file and return its content as a dictionary."""
    path = Path(path)
    with path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    if not isinstance(data, dict):
        raise ValueError(f"Top-level YAML at {path} must be a mapping.")
    return data


def deep_merge(base: Mapping[str, Any], override: Mapping[str, Any]) -> dict[str, Any]:
    """Recursively merge ``override`` into ``base`` without mutating inputs."""
    merged: dict[str, Any] = deepcopy(dict(base))
    for key, value in override.items():
        if (
            key in merged
            and isinstance(merged[key], Mapping)
            and isinstance(value, Mapping)
        ):
            merged[key] = deep_merge(merged[key], value)
        else:
            merged[key] = deepcopy(value)
    return merged


def load_experiment_config(
    default_path: str | Path,
    model_path: str | Path,
    dataset_path: str | Path,
    experiment_path: str | Path,
) -> dict[str, Any]:
    """Compose default, model, dataset and experiment configurations."""
    config = load_yaml(default_path)
    config = deep_merge(config, {"model": load_yaml(model_path)})
    config = deep_merge(config, {"dataset": load_yaml(dataset_path)})
    config = deep_merge(config, {"experiment": load_yaml(experiment_path)})
    return config
