# Cross-platform path utilities.
# Author: Haoyu Qiang.

from __future__ import annotations

import os
from pathlib import Path


def expand(path: str | Path) -> Path:
    """Expand ``~`` and environment variables, returning an absolute Path."""
    return Path(os.path.expandvars(os.path.expanduser(str(path)))).resolve()


def ensure_dir(path: str | Path) -> Path:
    """Create the directory if it does not exist and return its absolute Path."""
    target = expand(path)
    target.mkdir(parents=True, exist_ok=True)
    return target


def default_cache_root() -> Path:
    """Return the per-user cache root used by the project."""
    if os.name == "nt":
        base = os.environ.get("USERPROFILE", str(Path.home()))
        return expand(Path(base) / ".cache" / "papercode" / "datasets")
    return expand(Path.home() / ".cache" / "papercode" / "datasets")
