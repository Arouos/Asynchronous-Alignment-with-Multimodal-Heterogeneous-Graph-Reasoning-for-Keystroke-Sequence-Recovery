# Beam-search CTC decoding.
# Author: Haoyu Qiang.

from __future__ import annotations

from collections import defaultdict
from math import log

import torch


def _logsumexp(a: float, b: float) -> float:
    if a == float("-inf"):
        return b
    if b == float("-inf"):
        return a
    if a > b:
        return a + log(1.0 + 2.718281828 ** (b - a))
    return b + log(1.0 + 2.718281828 ** (a - b))


def beam_search_decode(log_probs: torch.Tensor, blank: int = 10, beam_width: int = 5) -> list[list[int]]:
    """Return the best-scoring symbol sequence per sample using prefix beam search."""
    if log_probs.dim() != 3:
        raise ValueError("log_probs must have shape [K, B, C].")
    k, b, c = log_probs.shape
    results: list[list[int]] = []
    log_probs_cpu = log_probs.detach().cpu()
    for sample_idx in range(b):
        beam: dict[tuple[int, ...], tuple[float, float]] = {(): (float("-inf"), 0.0)}
        for step in range(k):
            next_beam: dict[tuple[int, ...], tuple[float, float]] = defaultdict(lambda: (float("-inf"), float("-inf")))
            step_log = log_probs_cpu[step, sample_idx]
            for prefix, (p_nb, p_b) in beam.items():
                blank_logp = float(step_log[blank])
                cur_b, cur_nb = next_beam[prefix]
                next_beam[prefix] = (_logsumexp(cur_b, _logsumexp(p_nb, p_b) + blank_logp), cur_nb)
                for token in range(c):
                    if token == blank:
                        continue
                    token_logp = float(step_log[token])
                    extended = prefix + (token,) if not prefix or prefix[-1] != token else prefix
                    base = p_b if prefix and prefix[-1] == token else _logsumexp(p_nb, p_b)
                    cur_b2, cur_nb2 = next_beam[extended]
                    next_beam[extended] = (cur_b2, _logsumexp(cur_nb2, base + token_logp))
            pruned = sorted(next_beam.items(), key=lambda kv: _logsumexp(kv[1][0], kv[1][1]), reverse=True)[:beam_width]
            beam = dict(pruned)
        best_prefix, _ = max(beam.items(), key=lambda kv: _logsumexp(kv[1][0], kv[1][1]))
        results.append(list(best_prefix))
    return results
