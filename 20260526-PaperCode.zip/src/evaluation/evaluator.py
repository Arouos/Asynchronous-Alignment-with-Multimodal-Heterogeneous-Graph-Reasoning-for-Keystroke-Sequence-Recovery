# Unified evaluation routine.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch
from torch.utils.data import DataLoader

from ..metrics import (
    alignment_error_ms,
    character_error_rate,
    keystroke_f1,
    sequence_recovery_accuracy,
    topk_accuracy,
)
from ..utils.device import to_device
from .ctc_decoder import greedy_ctc_decode


class Evaluator:
    """Run a model over a DataLoader and aggregate the six target metrics."""

    def __init__(self, model: torch.nn.Module, device: torch.device, blank: int = 10) -> None:
        self.model = model
        self.device = device
        self.blank = blank

    @torch.no_grad()
    def evaluate(self, loader: DataLoader) -> dict[str, float]:
        self.model.eval()
        all_refs: list[list[int]] = []
        all_hyps: list[list[int]] = []
        all_logits: list[torch.Tensor] = []
        all_targets: list[torch.Tensor] = []
        for batch in loader:
            batch = to_device(batch, self.device)
            outputs = self.model(batch)
            log_probs = outputs.log_probs if hasattr(outputs, "log_probs") else outputs["log_probs"]
            hyp = greedy_ctc_decode(log_probs, blank=self.blank)
            digits = batch["digits"]
            lengths = batch["digit_lengths"].tolist()
            for sample_idx, length in enumerate(lengths):
                all_refs.append(digits[sample_idx, :length].tolist())
            all_hyps.extend(hyp)
            all_logits.append(log_probs.transpose(0, 1).reshape(-1, log_probs.size(-1)).cpu())
            all_targets.append(digits.flatten().cpu())

        if all_logits:
            logits_concat = torch.cat(all_logits, dim=0)
            targets_concat = torch.cat(all_targets, dim=0)
            top1 = topk_accuracy(logits_concat, targets_concat, k=1)
            top3 = topk_accuracy(logits_concat, targets_concat, k=3)
        else:
            top1 = 0.0
            top3 = 0.0

        return {
            "cer": character_error_rate(all_refs, all_hyps),
            "sra": sequence_recovery_accuracy(all_refs, all_hyps),
            "top1": top1,
            "top3": top3,
            "f1": keystroke_f1(
                pred_times_list=[list(range(len(seq))) for seq in all_hyps],
                pred_labels_list=all_hyps,
                gt_times_list=[list(range(len(seq))) for seq in all_refs],
                gt_labels_list=all_refs,
            ),
            "alignment_error": alignment_error_ms(
                pred_times_list=[list(range(len(seq))) for seq in all_hyps],
                gt_times_list=[list(range(len(seq))) for seq in all_refs],
            ),
        }
