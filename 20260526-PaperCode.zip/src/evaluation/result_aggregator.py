# Result aggregator for multi-seed experiments.
# Author: Haoyu Qiang.

from __future__ import annotations

import statistics
from typing import Iterable


def aggregate_results(per_seed: Iterable[dict[str, float]]) -> dict[str, dict[str, float]]:
    """Return per-metric ``{mean, std}`` over a collection of seed runs."""
    runs = list(per_seed)
    if not runs:
        return {}
    metric_names = sorted({key for run in runs for key in run})
    aggregated: dict[str, dict[str, float]] = {}
    for metric in metric_names:
        values = [run[metric] for run in runs if metric in run]
        if not values:
            continue
        mean = statistics.fmean(values)
        std = statistics.pstdev(values) if len(values) > 1 else 0.0
        aggregated[metric] = {"mean": float(mean), "std": float(std)}
    return aggregated
