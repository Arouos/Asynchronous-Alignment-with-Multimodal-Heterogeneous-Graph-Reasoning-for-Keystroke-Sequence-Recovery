# Greedy CTC decoding.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch


def greedy_ctc_decode(log_probs: torch.Tensor, blank: int = 10) -> list[list[int]]:
    """Decode ``log_probs`` of shape ``[K, B, C]`` to per-sample symbol sequences."""
    if log_probs.dim() != 3:
        raise ValueError("log_probs must have shape [K, B, C].")
    indices = log_probs.argmax(dim=-1)
    indices = indices.transpose(0, 1)
    sequences: list[list[int]] = []
    for sample in indices:
        collapsed: list[int] = []
        previous = -1
        for token in sample.tolist():
            if token == previous:
                continue
            previous = token
            if token != blank:
                collapsed.append(int(token))
        sequences.append(collapsed)
    return sequences
