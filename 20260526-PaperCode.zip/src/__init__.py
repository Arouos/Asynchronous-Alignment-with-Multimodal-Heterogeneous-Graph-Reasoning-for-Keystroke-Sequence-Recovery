# Top-level package marker for the AAM-HG reference implementation.
# Author: Haoyu Qiang.
