# Main comparison experiment runner.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

from ..evaluation.result_aggregator import aggregate_results
from .base_experiment import BaseExperiment


class MainComparisonRunner(BaseExperiment):
    """Sweep AAM-HG and the 11 baselines across the 10 datasets."""

    def run(self, dataset_configs: dict[str, dict[str, Any]]) -> dict[str, Any]:
        experiment_cfg = self.config.get("experiment", {})
        seeds = experiment_cfg.get("seeds", [0])
        models = experiment_cfg.get("models", [self.config.get("model", {}).get("name")])
        datasets = experiment_cfg.get("datasets", [])
        report: dict[str, dict[str, dict[str, dict[str, float]]]] = {}

        for model_name in models:
            model_overrides = self.config.get("models", {}).get(model_name, {})
            self.config["model"].update(model_overrides)
            self.config["model"]["name"] = model_name
            report[model_name] = {}
            for dataset_name in datasets:
                if dataset_name not in dataset_configs:
                    continue
                seed_metrics = []
                for seed in seeds:
                    artifacts = self.run_single(dataset_configs[dataset_name], seed=seed)
                    seed_metrics.append(artifacts.metrics)
                report[model_name][dataset_name] = aggregate_results(seed_metrics)
        return report
