# Base experiment driver.
# Author: Haoyu Qiang.

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch

from ..data.dataloader_factory import build_dataloaders, build_dataset
from ..evaluation.evaluator import Evaluator
from ..losses.combined_loss import AblationSwitches, CombinedLoss, LossWeights
from ..models.registry import build_model
from ..utils.device import resolve_device
from ..utils.seed import set_global_seed


@dataclass
class RunArtifacts:
    """Outputs collected from a single train+evaluate run."""

    metrics: dict[str, float]
    history: list[dict[str, float]]


class BaseExperiment:
    """Provide configuration parsing, model construction and dataloader assembly."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.device = resolve_device(config.get("device"))

    def _build_model(self) -> torch.nn.Module:
        return build_model(self.config["model"])

    def _build_dataloaders(self, dataset_cfg: dict[str, Any]):
        dataset = build_dataset(
            dataset_cfg=dataset_cfg,
            cache_dir=self.config.get("paths", {}).get("cache_root", "."),
            password_digits=int(self.config.get("experiment", {}).get("password_digits", 6)),
        )
        training = self.config.get("training", {})
        return build_dataloaders(
            dataset=dataset,
            batch_size=int(training.get("batch_size", 32)),
            num_workers=int(self.config.get("num_workers", 0)),
            seed=int(self.config.get("seed", 0)),
        )

    def _build_loss(self) -> CombinedLoss:
        model_cfg = self.config.get("model", {})
        weights = LossWeights(**model_cfg.get("loss_weights", {}))
        ablation = AblationSwitches(
            use_sparse_loss=bool(model_cfg.get("ablation", {}).get("use_sparse_loss", True)),
            use_degree_loss=bool(model_cfg.get("ablation", {}).get("use_degree_loss", True)),
            use_triangle_loss=bool(model_cfg.get("ablation", {}).get("use_triangle_loss", True)),
        )
        return CombinedLoss(weights=weights, ablation=ablation)

    def run_single(self, dataset_cfg: dict[str, Any], seed: int) -> RunArtifacts:
        set_global_seed(seed)
        model = self._build_model().to(self.device)
        loaders = self._build_dataloaders(dataset_cfg)
        evaluator = Evaluator(model, self.device, blank=int(self.config.get("model", {}).get("symbol_vocab_size", 11)) - 1)
        metrics = evaluator.evaluate(loaders["test"])
        return RunArtifacts(metrics=metrics, history=[])
