# SNR robustness experiment runner.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

from ..evaluation.result_aggregator import aggregate_results
from .base_experiment import BaseExperiment


class RobustnessSNRRunner(BaseExperiment):
    """Evaluate models across an SNR sweep."""

    def run(self, dataset_configs: dict[str, dict[str, Any]]) -> dict[str, Any]:
        experiment_cfg = self.config.get("experiment", {})
        snr_levels = experiment_cfg.get("snr_db_levels", [0])
        models = experiment_cfg.get("models", [])
        datasets = experiment_cfg.get("datasets", [])
        seeds = experiment_cfg.get("seeds", [0])
        report: dict[str, dict[str, dict[str, dict[str, dict[str, float]]]]] = {}

        for model_name in models:
            self.config["model"]["name"] = model_name
            report[model_name] = {}
            for dataset_name in datasets:
                if dataset_name not in dataset_configs:
                    continue
                report[model_name][dataset_name] = {}
                for snr in snr_levels:
                    self.config["experiment"]["current_snr_db"] = snr
                    seed_metrics = []
                    for seed in seeds:
                        artifacts = self.run_single(dataset_configs[dataset_name], seed=seed)
                        seed_metrics.append(artifacts.metrics)
                    report[model_name][dataset_name][f"snr_{snr}"] = aggregate_results(seed_metrics)
        return report
