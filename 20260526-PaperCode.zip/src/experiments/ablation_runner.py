# Ablation experiment runner.
# Author: Haoyu Qiang.

from __future__ import annotations

from copy import deepcopy
from typing import Any

from ..evaluation.result_aggregator import aggregate_results
from ..utils.config_loader import deep_merge
from .base_experiment import BaseExperiment


class AblationRunner(BaseExperiment):
    """Toggle individual modules and report CER deltas."""

    def run(self, dataset_configs: dict[str, dict[str, Any]]) -> dict[str, Any]:
        experiment_cfg = self.config.get("experiment", {})
        variants = experiment_cfg.get("variants", [])
        datasets = experiment_cfg.get("datasets", [])
        seeds = experiment_cfg.get("seeds", [0])
        report: dict[str, Any] = {}

        for variant in variants:
            variant_name = variant.get("name", "default")
            overrides = variant.get("overrides", {})
            original_model_cfg = deepcopy(self.config["model"])
            self.config["model"] = deep_merge(self.config["model"], overrides)
            report[variant_name] = {}
            for dataset_name in datasets:
                if dataset_name not in dataset_configs:
                    continue
                seed_metrics = []
                for seed in seeds:
                    artifacts = self.run_single(dataset_configs[dataset_name], seed=seed)
                    seed_metrics.append(artifacts.metrics)
                report[variant_name][dataset_name] = aggregate_results(seed_metrics)
            self.config["model"] = original_model_cfg
        return report
