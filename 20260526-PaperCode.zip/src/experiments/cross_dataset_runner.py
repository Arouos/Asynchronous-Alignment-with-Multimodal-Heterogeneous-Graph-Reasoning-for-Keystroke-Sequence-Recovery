# Cross-dataset generalization experiment runner.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

from ..evaluation.result_aggregator import aggregate_results
from .base_experiment import BaseExperiment


class CrossDatasetRunner(BaseExperiment):
    """Sweep train-test dataset pairs."""

    def run(self, dataset_configs: dict[str, dict[str, Any]]) -> dict[str, Any]:
        experiment_cfg = self.config.get("experiment", {})
        pairs = experiment_cfg.get("train_test_pairs", [])
        models = experiment_cfg.get("models", [])
        seeds = experiment_cfg.get("seeds", [0])
        report: dict[str, Any] = {}

        for model_name in models:
            self.config["model"]["name"] = model_name
            report[model_name] = {}
            for pair in pairs:
                train_name = pair.get("train")
                test_name = pair.get("test")
                if train_name not in dataset_configs or test_name not in dataset_configs:
                    continue
                seed_metrics = []
                for seed in seeds:
                    artifacts = self.run_single(dataset_configs[test_name], seed=seed)
                    seed_metrics.append(artifacts.metrics)
                report[model_name][f"{train_name}->{test_name}"] = aggregate_results(seed_metrics)
        return report
