# Soft degree budget penalty.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch


def soft_degree_penalty(
    cross_modal_weights: torch.Tensor,
    src_index: torch.Tensor,
    num_nodes: int,
    max_degree: float,
) -> torch.Tensor:
    r"""Compute :math:`\mathcal{L}_{\mathrm{deg}}`.

    The penalty squashes the per-node degree onto a budget ``d_max``:
    :math:`\mathcal{L}_{\mathrm{deg}} = \frac{1}{|V|} \sum_{i \in V}
    [\max(0, \sum_{j \in \mathcal{N}_{\mathrm{cross}}(i)} a_{ij} - d_{\max})]^2`.

    Args:
        cross_modal_weights: Tensor ``[E]`` of soft weights.
        src_index: Tensor ``[E]`` mapping each edge to its source node index.
        num_nodes: Total number of nodes ``|V|``.
        max_degree: Hyper-parameter ``d_max``.
    """
    if cross_modal_weights.numel() == 0:
        return cross_modal_weights.new_zeros(())
    degree = torch.zeros(num_nodes, device=cross_modal_weights.device, dtype=cross_modal_weights.dtype)
    degree = degree.scatter_add(0, src_index, cross_modal_weights)
    excess = (degree - max_degree).clamp(min=0)
    return (excess * excess).mean()
