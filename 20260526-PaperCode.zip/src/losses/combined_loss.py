# Combined training objective for AAM-HG.
# Author: Haoyu Qiang.

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn

from .ctc_loss import CTCObjective
from .soft_degree_loss import soft_degree_penalty
from .sparse_edge_loss import sparse_edge_penalty
from .triangle_consistency_loss import triangle_consistency_penalty


@dataclass
class LossWeights:
    """Loss term weights :math:`\\lambda_1, \\lambda_2, \\lambda_3`."""

    lambda1_sparse: float = 0.1
    lambda2_degree: float = 0.1
    lambda3_triangle: float = 0.05


@dataclass
class AblationSwitches:
    """Toggles for ablation studies."""

    use_sparse_loss: bool = True
    use_degree_loss: bool = True
    use_triangle_loss: bool = True


class CombinedLoss(nn.Module):
    r"""Sum-of-terms objective.

    :math:`\mathcal{L} = \mathcal{L}_{\mathrm{ctc}} + \lambda_1 \mathcal{L}_{\mathrm{sparse}}
    + \lambda_2 \mathcal{L}_{\mathrm{deg}} + \lambda_3 \mathcal{L}_{\mathrm{tri}}`.
    """

    def __init__(
        self,
        weights: LossWeights | None = None,
        ablation: AblationSwitches | None = None,
        blank: int = 0,
        max_degree: float = 8.0,
    ) -> None:
        super().__init__()
        self.weights = weights or LossWeights()
        self.ablation = ablation or AblationSwitches()
        self.ctc = CTCObjective(blank=blank)
        self.max_degree = float(max_degree)

    def forward(
        self,
        log_probs: torch.Tensor,
        targets: torch.Tensor,
        input_lengths: torch.Tensor,
        target_lengths: torch.Tensor,
        cross_modal_weights: torch.Tensor,
        cross_modal_src: torch.Tensor,
        cross_modal_mask: torch.Tensor,
        num_nodes: int,
        triangle_terms: tuple[torch.Tensor, torch.Tensor, torch.Tensor] | None = None,
    ) -> dict[str, torch.Tensor]:
        loss_ctc = self.ctc(log_probs, targets, input_lengths, target_lengths)
        total = loss_ctc
        report: dict[str, torch.Tensor] = {"ctc": loss_ctc}

        if self.ablation.use_sparse_loss:
            loss_sparse = sparse_edge_penalty(cross_modal_weights, cross_modal_mask)
            total = total + self.weights.lambda1_sparse * loss_sparse
            report["sparse"] = loss_sparse

        if self.ablation.use_degree_loss:
            loss_deg = soft_degree_penalty(
                cross_modal_weights,
                cross_modal_src,
                num_nodes=num_nodes,
                max_degree=self.max_degree,
            )
            total = total + self.weights.lambda2_degree * loss_deg
            report["degree"] = loss_deg

        if self.ablation.use_triangle_loss and triangle_terms is not None:
            loss_tri = triangle_consistency_penalty(*triangle_terms)
            total = total + self.weights.lambda3_triangle * loss_tri
            report["triangle"] = loss_tri

        report["total"] = total
        return report
