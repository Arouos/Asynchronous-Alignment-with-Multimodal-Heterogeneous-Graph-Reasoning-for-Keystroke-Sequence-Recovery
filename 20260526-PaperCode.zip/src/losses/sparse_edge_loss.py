# Sparse cross-modal edge penalty.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch


def sparse_edge_penalty(cross_modal_weights: torch.Tensor, edge_mask: torch.Tensor) -> torch.Tensor:
    r"""Compute :math:`\mathcal{L}_{\mathrm{sparse}}`.

    The penalty averages the retained cross-modal edge weights:
    :math:`\mathcal{L}_{\mathrm{sparse}} = \frac{1}{|\mathcal{E}_{\mathrm{cross}}|}
    \sum_{(i,j) \in \mathcal{E}_{\mathrm{cross}}} a_{ij}`.

    Args:
        cross_modal_weights: Tensor of shape ``[E]`` carrying the soft weight
            :math:`a_{ij}` for each retained cross-modal edge.
        edge_mask: Boolean tensor of shape ``[E]`` indicating active edges.
    """
    if cross_modal_weights.numel() == 0:
        return cross_modal_weights.new_zeros(())
    weights = cross_modal_weights * edge_mask.to(cross_modal_weights.dtype)
    denom = edge_mask.sum().clamp(min=1).to(cross_modal_weights.dtype)
    return weights.sum() / denom
