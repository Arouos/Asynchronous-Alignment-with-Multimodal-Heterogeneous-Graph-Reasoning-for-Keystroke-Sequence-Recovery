# Cross-modal triangle consistency penalty.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch


def triangle_consistency_penalty(
    a_av: torch.Tensor,
    a_ve: torch.Tensor,
    a_ae: torch.Tensor,
) -> torch.Tensor:
    r"""Compute :math:`\mathcal{L}_{\mathrm{tri}}`.

    The penalty enforces transitivity across the acoustic-vibration-electromagnetic
    triple:
    :math:`\mathcal{L}_{\mathrm{tri}} = \sum_{i,j,k}
    |a_{ij}^{a,v} a_{jk}^{v,e} - a_{ik}^{a,e}|`.

    Args:
        a_av: Soft match tensor of shape ``[N_a, N_v]`` between acoustic and vibration nodes.
        a_ve: Soft match tensor of shape ``[N_v, N_e]`` between vibration and electromagnetic nodes.
        a_ae: Soft match tensor of shape ``[N_a, N_e]`` between acoustic and electromagnetic nodes.
    """
    if a_av.numel() == 0 or a_ve.numel() == 0 or a_ae.numel() == 0:
        zero = a_av.new_zeros(()) if a_av.numel() else a_ae.new_zeros(())
        return zero
    composed = torch.matmul(a_av, a_ve)
    return (composed - a_ae).abs().sum()
