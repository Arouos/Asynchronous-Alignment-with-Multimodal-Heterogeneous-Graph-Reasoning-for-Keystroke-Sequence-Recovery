# Loss subpackage.
# Author: Haoyu Qiang.

from .combined_loss import CombinedLoss
from .ctc_loss import CTCObjective
from .soft_degree_loss import soft_degree_penalty
from .sparse_edge_loss import sparse_edge_penalty
from .triangle_consistency_loss import triangle_consistency_penalty

__all__ = [
    "CombinedLoss",
    "CTCObjective",
    "soft_degree_penalty",
    "sparse_edge_penalty",
    "triangle_consistency_penalty",
]
