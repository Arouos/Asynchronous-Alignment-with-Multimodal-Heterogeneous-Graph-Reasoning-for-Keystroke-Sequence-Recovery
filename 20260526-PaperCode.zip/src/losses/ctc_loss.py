# Connectionist Temporal Classification objective wrapper.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class CTCObjective(nn.Module):
    """Wraps :class:`torch.nn.CTCLoss` with explicit length handling.

    The expected input is the per-step symbol log-probability tensor
    ``log_probs`` with shape ``[K, B, |Y| + 1]`` and a target tensor of shape
    ``[B, T_max]`` padded with ``blank``.
    """

    def __init__(self, blank: int = 0, reduction: str = "mean", zero_infinity: bool = True) -> None:
        super().__init__()
        self.ctc = nn.CTCLoss(blank=blank, reduction=reduction, zero_infinity=zero_infinity)
        self.blank = blank

    def forward(
        self,
        log_probs: torch.Tensor,
        targets: torch.Tensor,
        input_lengths: torch.Tensor,
        target_lengths: torch.Tensor,
    ) -> torch.Tensor:
        if log_probs.dim() != 3:
            raise ValueError("log_probs must have shape [K, B, C].")
        return self.ctc(log_probs, targets, input_lengths, target_lengths)


def log_softmax_for_ctc(logits: torch.Tensor) -> torch.Tensor:
    """Apply log-softmax along the symbol dimension expected by ``CTCObjective``."""
    return F.log_softmax(logits, dim=-1)
