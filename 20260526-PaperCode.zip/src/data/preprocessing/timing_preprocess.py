# Keystroke timing preprocessing.
# Author: Haoyu Qiang.

from __future__ import annotations

import numpy as np


def normalize_timestamps(timestamps: np.ndarray) -> np.ndarray:
    """Shift the timestamp series so the first event is anchored at zero."""
    if timestamps.size == 0:
        return timestamps.astype(np.float32)
    return (timestamps - timestamps[0]).astype(np.float32)


def inter_keystroke_intervals(timestamps: np.ndarray) -> np.ndarray:
    if timestamps.size < 2:
        return np.zeros(0, dtype=np.float32)
    return np.diff(timestamps).astype(np.float32)


def summarize_timing(timestamps: np.ndarray) -> dict[str, float]:
    intervals = inter_keystroke_intervals(timestamps)
    if intervals.size == 0:
        return {"mean": 0.0, "std": 0.0, "min": 0.0, "max": 0.0}
    return {
        "mean": float(intervals.mean()),
        "std": float(intervals.std()),
        "min": float(intervals.min()),
        "max": float(intervals.max()),
    }
