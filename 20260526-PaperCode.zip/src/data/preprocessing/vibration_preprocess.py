# Vibration signal preprocessing.
# Author: Haoyu Qiang.

from __future__ import annotations

import numpy as np
from scipy.signal import butter, filtfilt


def bandpass(signal: np.ndarray, sample_rate: int, low_hz: float, high_hz: float, order: int = 4) -> np.ndarray:
    nyquist = sample_rate * 0.5
    low = max(low_hz / nyquist, 1.0e-3)
    high = min(high_hz / nyquist, 0.999)
    b, a = butter(order, [low, high], btype="band")
    return filtfilt(b, a, signal, axis=-1)


def detrend(signal: np.ndarray) -> np.ndarray:
    return signal - np.mean(signal, axis=-1, keepdims=True)


def envelope(signal: np.ndarray, window: int = 16) -> np.ndarray:
    abs_signal = np.abs(signal)
    kernel = np.ones(window, dtype=signal.dtype) / window
    return np.apply_along_axis(lambda x: np.convolve(x, kernel, mode="same"), axis=-1, arr=abs_signal)
