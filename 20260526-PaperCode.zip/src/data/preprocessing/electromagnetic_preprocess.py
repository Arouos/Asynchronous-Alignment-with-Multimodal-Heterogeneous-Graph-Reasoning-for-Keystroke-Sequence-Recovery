# Electromagnetic signal preprocessing.
# Author: Haoyu Qiang.

from __future__ import annotations

import numpy as np


def envelope_demodulation(signal: np.ndarray) -> np.ndarray:
    """Approximate envelope detector for narrow-band EM signals."""
    analytic = signal + 1j * np.imag(_hilbert_lite(signal))
    return np.abs(analytic)


def _hilbert_lite(signal: np.ndarray) -> np.ndarray:
    n = signal.shape[-1]
    spectrum = np.fft.fft(signal, axis=-1)
    h = np.zeros(n, dtype=spectrum.dtype)
    if n % 2 == 0:
        h[0] = 1
        h[n // 2] = 1
        h[1 : n // 2] = 2
    else:
        h[0] = 1
        h[1 : (n + 1) // 2] = 2
    return np.fft.ifft(spectrum * h, axis=-1)


def detect_scan_period(envelope_signal: np.ndarray, sample_rate: int) -> float:
    """Estimate the matrix scan period from the autocorrelation peak."""
    centered = envelope_signal - envelope_signal.mean(axis=-1, keepdims=True)
    autocorr = np.correlate(centered, centered, mode="full")
    autocorr = autocorr[autocorr.size // 2 :]
    if autocorr.size <= 2:
        return 0.0
    peak = int(np.argmax(autocorr[1:])) + 1
    return peak / sample_rate
