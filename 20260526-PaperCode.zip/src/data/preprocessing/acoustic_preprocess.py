# Acoustic signal preprocessing.
# Author: Haoyu Qiang.

from __future__ import annotations

import numpy as np


def resample_linear(signal: np.ndarray, source_rate: int, target_rate: int) -> np.ndarray:
    """Linear interpolation resampling for short keystroke clips."""
    if source_rate == target_rate:
        return signal.astype(np.float32)
    duration = signal.shape[-1] / source_rate
    new_len = max(1, int(round(duration * target_rate)))
    source_idx = np.linspace(0, signal.shape[-1] - 1, new_len)
    floor_idx = np.floor(source_idx).astype(np.int64)
    ceil_idx = np.clip(floor_idx + 1, 0, signal.shape[-1] - 1)
    frac = source_idx - floor_idx
    return (1 - frac) * signal[..., floor_idx] + frac * signal[..., ceil_idx]


def remove_dc(signal: np.ndarray) -> np.ndarray:
    return signal - signal.mean(axis=-1, keepdims=True)


def frame_signal(signal: np.ndarray, frame_length: int, hop_length: int) -> np.ndarray:
    """Split ``signal`` into overlapping frames of ``frame_length``."""
    num_frames = max(1, 1 + (signal.shape[-1] - frame_length) // hop_length)
    frames = np.zeros((*signal.shape[:-1], num_frames, frame_length), dtype=signal.dtype)
    for idx in range(num_frames):
        start = idx * hop_length
        end = start + frame_length
        frames[..., idx, :] = signal[..., start:end]
    return frames


def log_mel_spectrogram(
    signal: np.ndarray,
    sample_rate: int,
    n_fft: int = 1024,
    n_mels: int = 64,
    eps: float = 1e-10,
) -> np.ndarray:
    """Compute a simple log-mel spectrogram using only numpy."""
    window = np.hanning(n_fft).astype(signal.dtype)
    hop = n_fft // 2
    frames = frame_signal(signal, n_fft, hop)
    windowed = frames * window
    spectrum = np.fft.rfft(windowed, axis=-1)
    power = np.abs(spectrum) ** 2
    mel = np.linspace(0, sample_rate / 2, n_mels + 2)
    bins = np.linspace(0, sample_rate / 2, power.shape[-1])
    filt = np.zeros((n_mels, power.shape[-1]), dtype=signal.dtype)
    for m in range(1, n_mels + 1):
        left, center, right = mel[m - 1], mel[m], mel[m + 1]
        left_mask = (bins >= left) & (bins <= center)
        right_mask = (bins >= center) & (bins <= right)
        if center > left:
            filt[m - 1, left_mask] = (bins[left_mask] - left) / (center - left)
        if right > center:
            filt[m - 1, right_mask] = (right - bins[right_mask]) / (right - center)
    mel_spectrum = power @ filt.T
    return np.log(mel_spectrum + eps)
