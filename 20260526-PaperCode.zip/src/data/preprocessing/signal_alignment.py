# Cross-modality time-axis alignment.
# Author: Haoyu Qiang.

from __future__ import annotations

import numpy as np


def align_to_common_axis(
    signals: dict[str, np.ndarray],
    sample_rates: dict[str, int],
    target_rate: int,
) -> dict[str, np.ndarray]:
    """Resample each modality to ``target_rate`` while preserving inter-modal delays."""
    aligned: dict[str, np.ndarray] = {}
    for modality, signal in signals.items():
        source_rate = sample_rates[modality]
        if source_rate == target_rate:
            aligned[modality] = signal.astype(np.float32)
            continue
        duration = signal.shape[-1] / source_rate
        new_len = max(1, int(round(duration * target_rate)))
        idx = np.linspace(0, signal.shape[-1] - 1, new_len)
        floor_idx = np.floor(idx).astype(np.int64)
        ceil_idx = np.clip(floor_idx + 1, 0, signal.shape[-1] - 1)
        frac = idx - floor_idx
        aligned[modality] = ((1 - frac) * signal[..., floor_idx] + frac * signal[..., ceil_idx]).astype(np.float32)
    return aligned
