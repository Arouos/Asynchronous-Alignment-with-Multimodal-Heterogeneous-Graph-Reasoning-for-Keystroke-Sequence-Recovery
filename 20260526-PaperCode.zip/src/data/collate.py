# Variable-length collate function.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch
import torch.nn.functional as F


def pad_to_length(tensor: torch.Tensor, length: int) -> torch.Tensor:
    if tensor.size(-1) == length:
        return tensor
    if tensor.size(-1) > length:
        return tensor[..., :length]
    return F.pad(tensor, (0, length - tensor.size(-1)))


def collate_keystroke_batch(items: list[dict[str, Any]]) -> dict[str, Any]:
    """Collate a list of dataset samples into a batched tensor dictionary."""
    modalities = sorted({modality for item in items for modality in item["signals"]})
    signals: dict[str, torch.Tensor] = {}
    masks: dict[str, torch.Tensor] = {}
    for modality in modalities:
        lengths = [item["signals"][modality].size(-1) for item in items if modality in item["signals"]]
        max_len = max(lengths) if lengths else 1
        padded = []
        modality_mask = []
        for item in items:
            if modality in item["signals"]:
                tensor = pad_to_length(item["signals"][modality], max_len)
                padded.append(tensor)
                modality_mask.append(torch.tensor(1.0))
            else:
                padded.append(torch.zeros(max_len))
                modality_mask.append(torch.tensor(0.0))
        signals[modality] = torch.stack(padded)
        masks[modality] = torch.stack(modality_mask)
    digits_lengths = [item["digits"].size(0) for item in items]
    digits_max = max(digits_lengths)
    digits_padded = torch.zeros(len(items), digits_max, dtype=torch.long)
    for idx, item in enumerate(items):
        digits_padded[idx, : item["digits"].size(0)] = item["digits"]
    digit_lengths = torch.tensor(digits_lengths, dtype=torch.long)
    return {
        "signals": signals,
        "modality_mask": masks,
        "digits": digits_padded,
        "digit_lengths": digit_lengths,
        "meta": [item.get("meta", {}) for item in items],
    }
