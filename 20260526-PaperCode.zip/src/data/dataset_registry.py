# Dataset registry mapping names to download metadata.
# Author: Haoyu Qiang.

from __future__ import annotations

from dataclasses import dataclass

# The URLs below point to public GitHub mirrors. When a definitive mirror is
# not yet known the entry uses a placeholder which must be populated through
# the dataset YAML configuration before fetching.


@dataclass(frozen=True)
class DatasetEntry:
    name: str
    modalities: tuple[str, ...]
    github_url: str
    cache_subdir: str
    checksum: str | None = None
    archive_format: str = "zip"


_REGISTRY: dict[str, DatasetEntry] = {
    "cmu": DatasetEntry(
        name="cmu",
        modalities=("timing",),
        github_url="https://github.com/example-mirror/cmu-keystroke-dynamics/archive/refs/heads/main.zip",
        cache_subdir="cmu",
    ),
    "bbmas": DatasetEntry(
        name="bbmas",
        modalities=("acoustic", "vibration", "timing"),
        github_url="https://github.com/example-mirror/bbmas/archive/refs/heads/main.zip",
        cache_subdir="bbmas",
    ),
    "aalto": DatasetEntry(
        name="aalto",
        modalities=("timing",),
        github_url="https://github.com/example-mirror/aalto-136m-keystrokes/archive/refs/heads/main.zip",
        cache_subdir="aalto",
    ),
    "clarkson2": DatasetEntry(
        name="clarkson2",
        modalities=("timing",),
        github_url="https://github.com/example-mirror/clarkson2/archive/refs/heads/main.zip",
        cache_subdir="clarkson2",
    ),
    "buffalo": DatasetEntry(
        name="buffalo",
        modalities=("timing",),
        github_url="https://github.com/example-mirror/buffalo-free-text/archive/refs/heads/main.zip",
        cache_subdir="buffalo",
    ),
    "greyc": DatasetEntry(
        name="greyc",
        modalities=("timing",),
        github_url="https://github.com/example-mirror/greyc-keystroke/archive/refs/heads/main.zip",
        cache_subdir="greyc",
    ),
    "vuagnoux_pasini": DatasetEntry(
        name="vuagnoux_pasini",
        modalities=("electromagnetic",),
        github_url="https://github.com/example-mirror/vuagnoux-pasini-em/archive/refs/heads/main.zip",
        cache_subdir="vuagnoux_pasini",
    ),
    "zzt_acoustic": DatasetEntry(
        name="zzt_acoustic",
        modalities=("acoustic",),
        github_url="https://github.com/example-mirror/zhuang-zhou-tygar-acoustic/archive/refs/heads/main.zip",
        cache_subdir="zzt_acoustic",
    ),
    "asonov_agrawal": DatasetEntry(
        name="asonov_agrawal",
        modalities=("acoustic",),
        github_url="https://github.com/example-mirror/asonov-agrawal-acoustic/archive/refs/heads/main.zip",
        cache_subdir="asonov_agrawal",
    ),
    "spiphone": DatasetEntry(
        name="spiphone",
        modalities=("vibration",),
        github_url="https://github.com/example-mirror/spiphone-vibration/archive/refs/heads/main.zip",
        cache_subdir="spiphone",
    ),
}


def get_entry(name: str) -> DatasetEntry:
    if name not in _REGISTRY:
        raise KeyError(f"Unknown dataset {name!r}. Registered: {sorted(_REGISTRY)}")
    return _REGISTRY[name]


def list_datasets() -> list[str]:
    return sorted(_REGISTRY)
