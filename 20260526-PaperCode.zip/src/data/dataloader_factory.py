# DataLoader factory for training, validation and test splits.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

from torch.utils.data import DataLoader, Dataset, random_split

from .collate import collate_keystroke_batch
from .datasets import (
    AaltoDataset,
    AsonovAgrawalDataset,
    BBMASDataset,
    BaseKeystrokeDataset,
    BuffaloDataset,
    CMUDataset,
    ClarksonIIDataset,
    GREYCDataset,
    SPiPhoneDataset,
    VuagnouxPasiniDataset,
    ZZTAcousticDataset,
)


_DATASET_CLASSES: dict[str, type[BaseKeystrokeDataset]] = {
    "cmu": CMUDataset,
    "bbmas": BBMASDataset,
    "aalto": AaltoDataset,
    "clarkson2": ClarksonIIDataset,
    "buffalo": BuffaloDataset,
    "greyc": GREYCDataset,
    "vuagnoux_pasini": VuagnouxPasiniDataset,
    "zzt_acoustic": ZZTAcousticDataset,
    "asonov_agrawal": AsonovAgrawalDataset,
    "spiphone": SPiPhoneDataset,
}


def build_dataset(dataset_cfg: dict[str, Any], cache_dir: str, password_digits: int) -> BaseKeystrokeDataset:
    name = dataset_cfg.get("name")
    if name not in _DATASET_CLASSES:
        raise KeyError(f"Unknown dataset {name!r}.")
    cls = _DATASET_CLASSES[name]
    dataset = cls(cache_dir=cache_dir, password_digits=password_digits)
    if not len(dataset):
        dataset.populate_synthetic(num_samples=int(dataset_cfg.get("synthetic_samples", 64)))
    return dataset


def split_dataset(
    dataset: Dataset,
    ratios: tuple[float, float, float] = (0.8, 0.1, 0.1),
    seed: int = 0,
) -> tuple[Dataset, Dataset, Dataset]:
    total = len(dataset)
    train_size = int(ratios[0] * total)
    val_size = int(ratios[1] * total)
    test_size = total - train_size - val_size
    generator = None
    if seed is not None:
        import torch

        generator = torch.Generator().manual_seed(seed)
    return tuple(random_split(dataset, [train_size, val_size, test_size], generator=generator))


def build_dataloaders(
    dataset: Dataset,
    batch_size: int,
    num_workers: int,
    seed: int = 0,
) -> dict[str, DataLoader]:
    train_set, val_set, test_set = split_dataset(dataset, seed=seed)
    common = {
        "batch_size": batch_size,
        "num_workers": num_workers,
        "collate_fn": collate_keystroke_batch,
    }
    return {
        "train": DataLoader(train_set, shuffle=True, **common),
        "val": DataLoader(val_set, shuffle=False, **common),
        "test": DataLoader(test_set, shuffle=False, **common),
    }
