# Streaming download utility for GitHub archives.
# Author: Haoyu Qiang.

from __future__ import annotations

import hashlib
import shutil
from pathlib import Path

import requests
from tqdm import tqdm


def stream_download(url: str, destination: Path, chunk_size: int = 1 << 20) -> Path:
    """Download ``url`` to ``destination`` with resumable streaming."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    headers = {}
    mode = "wb"
    existing = 0
    if destination.exists():
        existing = destination.stat().st_size
        headers["Range"] = f"bytes={existing}-"
        mode = "ab"
    with requests.get(url, stream=True, timeout=60, headers=headers) as response:
        if response.status_code in (200, 206):
            total = int(response.headers.get("Content-Length", 0)) + existing
            with destination.open(mode) as handle, tqdm(
                total=total,
                initial=existing,
                unit="B",
                unit_scale=True,
                desc=destination.name,
            ) as progress:
                for chunk in response.iter_content(chunk_size=chunk_size):
                    if chunk:
                        handle.write(chunk)
                        progress.update(len(chunk))
        else:
            raise RuntimeError(f"Download failed with status {response.status_code} for {url}")
    return destination


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_remove(path: Path) -> None:
    path = Path(path)
    if path.is_file():
        path.unlink()
    elif path.is_dir():
        shutil.rmtree(path)
