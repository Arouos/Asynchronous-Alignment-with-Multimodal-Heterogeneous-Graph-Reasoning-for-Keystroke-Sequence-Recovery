# Additive noise injection used by the SNR robustness experiment.
# Author: Haoyu Qiang.

from __future__ import annotations

import numpy as np


def add_white_noise(signal: np.ndarray, snr_db: float, rng: np.random.Generator | None = None) -> np.ndarray:
    """Inject additive white Gaussian noise at the requested SNR."""
    rng = rng or np.random.default_rng()
    signal_power = float(np.mean(signal ** 2)) + 1e-12
    noise_power = signal_power / (10 ** (snr_db / 10))
    noise = rng.normal(0.0, np.sqrt(noise_power), size=signal.shape).astype(signal.dtype)
    return signal + noise


def add_mixture_noise(
    signal: np.ndarray,
    noise_profiles: dict[str, np.ndarray],
    weights: dict[str, float],
    snr_db: float,
    rng: np.random.Generator | None = None,
) -> np.ndarray:
    """Mix several noise profiles and scale to the requested SNR."""
    rng = rng or np.random.default_rng()
    if not noise_profiles:
        return add_white_noise(signal, snr_db, rng)
    combined = np.zeros_like(signal)
    total_weight = sum(weights.get(name, 0.0) for name in noise_profiles) or 1.0
    for name, profile in noise_profiles.items():
        weight = weights.get(name, 0.0) / total_weight
        if profile.shape[-1] < signal.shape[-1]:
            repeated = np.tile(profile, int(np.ceil(signal.shape[-1] / profile.shape[-1])))
            profile = repeated[: signal.shape[-1]]
        else:
            offset = rng.integers(0, profile.shape[-1] - signal.shape[-1] + 1)
            profile = profile[offset : offset + signal.shape[-1]]
        combined = combined + weight * profile
    signal_power = float(np.mean(signal ** 2)) + 1e-12
    noise_power = signal_power / (10 ** (snr_db / 10))
    combined_power = float(np.mean(combined ** 2)) + 1e-12
    gain = np.sqrt(noise_power / combined_power)
    return signal + gain * combined
