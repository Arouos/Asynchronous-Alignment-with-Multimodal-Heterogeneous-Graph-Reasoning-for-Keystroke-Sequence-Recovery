# Modality dropout for the modality-missing experiment.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Iterable

import numpy as np


def zero_out_modalities(
    signals: dict[str, np.ndarray],
    drop: Iterable[str],
) -> dict[str, np.ndarray]:
    """Return a copy of ``signals`` with the ``drop`` modalities zeroed."""
    drop_set = set(drop)
    cleaned: dict[str, np.ndarray] = {}
    for modality, signal in signals.items():
        cleaned[modality] = np.zeros_like(signal) if modality in drop_set else signal
    return cleaned


def keep_modalities(
    signals: dict[str, np.ndarray],
    keep: Iterable[str],
) -> dict[str, np.ndarray]:
    keep_set = set(keep)
    drop = [modality for modality in signals if modality not in keep_set]
    return zero_out_modalities(signals, drop)
