# Inter-modality asynchronous offset augmentation.
# Author: Haoyu Qiang.

from __future__ import annotations

import numpy as np


def shift_signal(signal: np.ndarray, offset_samples: int) -> np.ndarray:
    """Shift ``signal`` along the last axis by ``offset_samples`` positions."""
    if offset_samples == 0:
        return signal
    shifted = np.zeros_like(signal)
    if offset_samples > 0:
        shifted[..., offset_samples:] = signal[..., : signal.shape[-1] - offset_samples]
    else:
        shift = -offset_samples
        shifted[..., : signal.shape[-1] - shift] = signal[..., shift:]
    return shifted


def sample_offsets(
    modalities: list[str],
    distribution: str,
    max_offset_ms: float,
    sample_rate: int,
    rng: np.random.Generator | None = None,
) -> dict[str, int]:
    """Draw a per-modality offset in samples."""
    rng = rng or np.random.default_rng()
    max_offset_samples = int(max_offset_ms * sample_rate / 1000.0)
    offsets: dict[str, int] = {}
    for modality in modalities:
        if distribution == "uniform":
            offsets[modality] = int(rng.integers(-max_offset_samples, max_offset_samples + 1))
        else:
            offsets[modality] = int(rng.normal(0.0, max_offset_samples / 3.0))
    return offsets
