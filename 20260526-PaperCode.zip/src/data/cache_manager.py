# Local cache directory orchestration.
# Author: Haoyu Qiang.

from __future__ import annotations

import json
import zipfile
from pathlib import Path

from ..utils.path_utils import default_cache_root, ensure_dir


class CacheManager:
    """Wrapper around the per-user cache directory tree."""

    def __init__(self, root: str | Path | None = None) -> None:
        self.root: Path = ensure_dir(root or default_cache_root())
        self.index_path: Path = self.root / "index.json"

    def dataset_dir(self, name: str) -> Path:
        return ensure_dir(self.root / name)

    def archive_path(self, name: str, archive_format: str) -> Path:
        return self.dataset_dir(name) / f"{name}.{archive_format}"

    def extract_archive(self, archive: Path, target_dir: Path) -> None:
        target_dir = Path(target_dir)
        target_dir.mkdir(parents=True, exist_ok=True)
        if archive.suffix.lower() == ".zip":
            with zipfile.ZipFile(archive) as zf:
                zf.extractall(target_dir)
        else:
            raise NotImplementedError(f"Unsupported archive format: {archive.suffix}")

    def write_index(self, payload: dict) -> None:
        with self.index_path.open("w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, ensure_ascii=False)

    def read_index(self) -> dict:
        if not self.index_path.exists():
            return {}
        with self.index_path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
