# Password sampling utilities.
# Author: Haoyu Qiang.
