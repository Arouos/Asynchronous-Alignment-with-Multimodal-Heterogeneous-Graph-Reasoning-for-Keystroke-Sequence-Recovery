# Numeric password substring sampler.
# Author: Haoyu Qiang.

from __future__ import annotations

import random
from typing import Sequence


def sample_substring(
    sequence: Sequence[int],
    length: int,
    rng: random.Random | None = None,
) -> tuple[int, list[int]]:
    """Draw a length-``length`` substring from ``sequence``.

    Returns ``(start_index, substring)``.
    """
    if len(sequence) < length:
        raise ValueError("Sequence shorter than required length.")
    rng = rng or random.Random()
    start = rng.randint(0, len(sequence) - length)
    return start, list(sequence[start : start + length])


def all_substrings(sequence: Sequence[int], length: int, stride: int = 1) -> list[list[int]]:
    return [list(sequence[i : i + length]) for i in range(0, len(sequence) - length + 1, stride)]
