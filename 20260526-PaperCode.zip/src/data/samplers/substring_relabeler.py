# Relabel raw key sequences onto the project symbol set.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Iterable


def keys_to_digits(keys: Iterable[str | int]) -> list[int]:
    """Map raw key tokens to the integer digit alphabet 0..9."""
    out: list[int] = []
    for token in keys:
        if isinstance(token, int) and 0 <= token <= 9:
            out.append(token)
        elif isinstance(token, str) and token.isdigit() and len(token) == 1:
            out.append(int(token))
    return out


def digits_to_labels(digits: list[int], blank: int = 10) -> list[int]:
    """Shift the digit alphabet so the blank symbol occupies position ``blank``."""
    if any(d == blank for d in digits):
        raise ValueError("Digit collides with blank token.")
    return list(digits)
