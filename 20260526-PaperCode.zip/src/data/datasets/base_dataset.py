# Base dataset class for keystroke recovery experiments.
# Author: Haoyu Qiang.

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.utils.data import Dataset


@dataclass
class KeystrokeSample:
    """Container holding all per-sample information used downstream."""

    signals: dict[str, np.ndarray]
    timestamps: np.ndarray
    digits: list[int]
    sample_rate: dict[str, int]
    meta: dict[str, Any] = field(default_factory=dict)


class BaseKeystrokeDataset(Dataset):
    """Base class enforcing the project sample contract.

    Concrete datasets should populate ``self._samples`` with
    :class:`KeystrokeSample` records during initialisation.
    """

    def __init__(self, cache_dir: str | Path, modalities: list[str], password_digits: int) -> None:
        super().__init__()
        self.cache_dir = Path(cache_dir)
        self.modalities = list(modalities)
        self.password_digits = int(password_digits)
        self._samples: list[KeystrokeSample] = []

    def __len__(self) -> int:
        return len(self._samples)

    def __getitem__(self, index: int) -> dict[str, Any]:
        sample = self._samples[index]
        signals = {modality: torch.from_numpy(sample.signals[modality]).float() for modality in self.modalities if modality in sample.signals}
        return {
            "signals": signals,
            "timestamps": torch.from_numpy(sample.timestamps).float(),
            "digits": torch.tensor(sample.digits, dtype=torch.long),
            "sample_rate": sample.sample_rate,
            "meta": sample.meta,
        }

    def synth_random_sample(self, rng: np.random.Generator) -> KeystrokeSample:
        """Synthesize a placeholder sample when the dataset archive is unavailable."""
        length = max(self.password_digits, 1)
        digits = rng.integers(0, 10, size=length).tolist()
        timestamps = np.cumsum(rng.integers(80, 240, size=length)).astype(np.float32)
        signals: dict[str, np.ndarray] = {}
        sample_rate: dict[str, int] = {}
        for modality in self.modalities:
            rate = {"acoustic": 16000, "vibration": 500, "electromagnetic": 200000, "timing": 1000}.get(modality, 16000)
            sample_rate[modality] = rate
            duration_samples = int(rate * (timestamps[-1] / 1000.0 + 1.0))
            signals[modality] = rng.normal(0.0, 1.0, size=duration_samples).astype(np.float32)
        return KeystrokeSample(signals=signals, timestamps=timestamps, digits=list(digits), sample_rate=sample_rate)

    def populate_synthetic(self, num_samples: int, seed: int = 0) -> None:
        """Fill the dataset with synthetic placeholders for smoke testing."""
        rng = np.random.default_rng(seed)
        self._samples = [self.synth_random_sample(rng) for _ in range(num_samples)]
