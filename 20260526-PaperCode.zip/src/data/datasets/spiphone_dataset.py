# (sp)iPhone vibration dataset wrapper.
# Author: Haoyu Qiang.

from __future__ import annotations

from pathlib import Path

from .base_dataset import BaseKeystrokeDataset


class SPiPhoneDataset(BaseKeystrokeDataset):
    """(sp)iPhone vibration loader."""

    def __init__(self, cache_dir: str | Path, password_digits: int = 6) -> None:
        super().__init__(cache_dir=cache_dir, modalities=["vibration"], password_digits=password_digits)
