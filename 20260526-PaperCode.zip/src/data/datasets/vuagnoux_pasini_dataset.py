# Vuagnoux-Pasini electromagnetic leakage dataset wrapper.
# Author: Haoyu Qiang.

from __future__ import annotations

from pathlib import Path

from .base_dataset import BaseKeystrokeDataset


class VuagnouxPasiniDataset(BaseKeystrokeDataset):
    """Vuagnoux-Pasini electromagnetic loader."""

    def __init__(self, cache_dir: str | Path, password_digits: int = 6) -> None:
        super().__init__(cache_dir=cache_dir, modalities=["electromagnetic"], password_digits=password_digits)
