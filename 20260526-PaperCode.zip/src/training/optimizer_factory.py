# Optimizer factory.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any, Iterable

import torch
import torch.optim as optim


def build_optimizer(parameters: Iterable[torch.nn.Parameter], cfg: dict[str, Any]) -> torch.optim.Optimizer:
    name = cfg.get("name", "adamw").lower()
    lr = float(cfg.get("lr", 1.0e-3))
    weight_decay = float(cfg.get("weight_decay", 0.0))
    if name == "adamw":
        betas = tuple(cfg.get("betas", (0.9, 0.999)))
        return optim.AdamW(parameters, lr=lr, betas=betas, weight_decay=weight_decay)
    if name == "sgd":
        return optim.SGD(parameters, lr=lr, momentum=float(cfg.get("momentum", 0.9)), weight_decay=weight_decay)
    if name == "lamb":
        try:
            from torch.optim import Lamb  # type: ignore[attr-defined]
        except ImportError as exc:
            raise ImportError("LAMB optimizer not available in this PyTorch build.") from exc
        return Lamb(parameters, lr=lr, weight_decay=weight_decay)
    raise ValueError(f"Unsupported optimizer: {name!r}")
