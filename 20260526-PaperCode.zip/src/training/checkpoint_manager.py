# Training checkpoint manager.
# Author: Haoyu Qiang.

from __future__ import annotations

from pathlib import Path
from typing import Any

import torch


class CheckpointManager:
    """Persist and restore training state."""

    def __init__(self, directory: str | Path) -> None:
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)

    def save(self, name: str, payload: dict[str, Any]) -> Path:
        target = self.directory / f"{name}.pt"
        torch.save(payload, target)
        return target

    def load(self, name: str, map_location: str | torch.device = "cpu") -> dict[str, Any]:
        source = self.directory / f"{name}.pt"
        return torch.load(source, map_location=map_location)

    def best_path(self, name: str = "best") -> Path:
        return self.directory / f"{name}.pt"
