# Unified training loop.
# Author: Haoyu Qiang.

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from ..utils.device import to_device
from .checkpoint_manager import CheckpointManager
from .gradient_utils import clip_gradients
from .optimizer_factory import build_optimizer
from .scheduler_factory import build_scheduler


@dataclass
class TrainerState:
    epoch: int = 0
    best_metric: float = float("inf")
    patience_counter: int = 0


class Trainer:
    """Training driver tied to the project model + loss conventions.

    ``loss_callable(outputs, batch)`` should return a dictionary with at least
    a ``"total"`` key. ``evaluator(loader)`` should return a scalar metric used
    to track the best checkpoint (lower is better).
    """

    def __init__(
        self,
        model: nn.Module,
        loss_callable: Callable[[Any, dict[str, Any]], dict[str, torch.Tensor]],
        train_loader: DataLoader,
        val_loader: DataLoader,
        device: torch.device,
        cfg: dict[str, Any],
        evaluator: Callable[[DataLoader], float] | None = None,
        checkpoint_dir: str | Path = "checkpoints",
    ) -> None:
        self.model = model.to(device)
        self.loss_callable = loss_callable
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        self.cfg = cfg
        self.evaluator = evaluator
        self.checkpoint_manager = CheckpointManager(checkpoint_dir)
        params = [p for p in self.model.parameters() if p.requires_grad]
        self.optimizer = build_optimizer(params, cfg.get("optimizer", {}))
        steps_per_epoch = max(1, len(train_loader))
        total_steps = steps_per_epoch * int(cfg.get("training", {}).get("epochs", 1))
        self.scheduler = build_scheduler(self.optimizer, cfg.get("scheduler", {}), total_steps)
        self.state = TrainerState()

    def train(self) -> dict[str, Any]:
        training_cfg = self.cfg.get("training", {})
        epochs = int(training_cfg.get("epochs", 1))
        grad_clip = float(training_cfg.get("grad_clip_norm", 0.0))
        patience = int(training_cfg.get("early_stop_patience", 0))

        history: list[dict[str, float]] = []
        for epoch in range(epochs):
            self.state.epoch = epoch
            self.model.train()
            running = 0.0
            count = 0
            for batch in self.train_loader:
                batch = to_device(batch, self.device)
                self.optimizer.zero_grad(set_to_none=True)
                outputs = self.model(batch)
                losses = self.loss_callable(outputs, batch)
                loss = losses["total"]
                loss.backward()
                clip_gradients(self.model.parameters(), grad_clip)
                self.optimizer.step()
                self.scheduler.step()
                running += float(loss.detach().cpu())
                count += 1

            train_loss = running / max(count, 1)
            val_metric = self.evaluator(self.val_loader) if self.evaluator is not None else train_loss
            history.append({"epoch": epoch, "train_loss": train_loss, "val_metric": val_metric})

            if val_metric < self.state.best_metric:
                self.state.best_metric = val_metric
                self.state.patience_counter = 0
                self.checkpoint_manager.save(
                    "best",
                    {
                        "model": self.model.state_dict(),
                        "optimizer": self.optimizer.state_dict(),
                        "scheduler": self.scheduler.state_dict(),
                        "epoch": epoch,
                    },
                )
            else:
                self.state.patience_counter += 1
                if patience > 0 and self.state.patience_counter >= patience:
                    break

        return {"history": history, "best_metric": self.state.best_metric}
