# Learning rate scheduler factory.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch
from torch.optim.lr_scheduler import CosineAnnealingLR, LambdaLR, StepLR, _LRScheduler


def build_scheduler(optimizer: torch.optim.Optimizer, cfg: dict[str, Any], total_steps: int) -> _LRScheduler:
    name = cfg.get("name", "cosine").lower()
    if name == "cosine":
        return CosineAnnealingLR(optimizer, T_max=total_steps, eta_min=float(cfg.get("min_lr", 1.0e-6)))
    if name == "step":
        return StepLR(optimizer, step_size=int(cfg.get("step_size", 10)), gamma=float(cfg.get("gamma", 0.1)))
    if name == "linear_warmup":
        warmup = int(cfg.get("warmup_steps", max(1, total_steps // 10)))

        def lr_lambda(step: int) -> float:
            if step < warmup:
                return step / max(1, warmup)
            return max(0.0, (total_steps - step) / max(1, total_steps - warmup))

        return LambdaLR(optimizer, lr_lambda)
    raise ValueError(f"Unsupported scheduler: {name!r}")
