# Gradient utilities for clipping and accumulation.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Iterable

import torch


def clip_gradients(parameters: Iterable[torch.nn.Parameter], max_norm: float | None) -> float:
    if max_norm is None or max_norm <= 0:
        return 0.0
    total_norm = torch.nn.utils.clip_grad_norm_(parameters, max_norm=max_norm)
    return float(total_norm)


class GradientAccumulator:
    """Tracks how many micro-batches contributed to the current update."""

    def __init__(self, accumulation_steps: int = 1) -> None:
        self.accumulation_steps = max(1, int(accumulation_steps))
        self._counter = 0

    def step(self) -> bool:
        self._counter = (self._counter + 1) % self.accumulation_steps
        return self._counter == 0
