# Registry mapping model names to constructor callables.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any, Callable

import torch.nn as nn

from .aam_hg import AAMHGModel
from .baselines import (
    CM2Model,
    HeimdallModel,
    InfoMAEModel,
    M3JEPAModel,
    MEAModel,
    PracticalASCAModel,
    RDLModel,
    RGTModel,
    SEHTGNNModel,
    VRecKeyModel,
    WOOTLLMModel,
)


_REGISTRY: dict[str, Callable[[dict[str, Any]], nn.Module]] = {
    "aam_hg": AAMHGModel,
    "cm2": CM2Model,
    "m3_jepa": M3JEPAModel,
    "infomae": InfoMAEModel,
    "mea": MEAModel,
    "practical_asca": PracticalASCAModel,
    "woot_llm": WOOTLLMModel,
    "vreckey": VRecKeyModel,
    "heimdall": HeimdallModel,
    "rgt": RGTModel,
    "rdl": RDLModel,
    "se_htgnn": SEHTGNNModel,
}


def build_model(model_cfg: dict[str, Any]) -> nn.Module:
    """Instantiate a model based on its configuration dictionary."""
    name = model_cfg.get("name")
    if name not in _REGISTRY:
        raise KeyError(f"Unknown model name: {name!r}. Registered: {sorted(_REGISTRY)}")
    return _REGISTRY[name](model_cfg)


def available_models() -> list[str]:
    return sorted(_REGISTRY)
