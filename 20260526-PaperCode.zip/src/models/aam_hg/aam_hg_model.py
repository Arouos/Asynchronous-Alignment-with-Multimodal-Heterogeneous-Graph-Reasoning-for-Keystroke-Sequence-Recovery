# End-to-end AAM-HG model definition.
# Author: Haoyu Qiang.

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import torch
import torch.nn as nn

from .action_relation_projection import ActionRelationProjection, build_node_relation_matrix
from .candidate_construction import CandidateNodeBuilder
from .ctc_head import CTCHead
from .delay_prior import DelayPrior
from .graph_coarsening import GraphCoarsening
from .graph_construction import GraphConstruction
from .modal_encoder import ModalEncoderBank
from .node_embedding import NodeEmbedding
from .ordered_decoder import OrderedDecoder
from .relation_aware_gnn import RelationAwareGNNLayer
from .scale_aggregation import ScaleAdaptiveAggregator
from .temporal_gating import TemporalGating
from .triangle_consistency import extract_triangle_terms


@dataclass
class AAMHGOutputs:
    """Container for AAM-HG forward outputs."""

    log_probs: torch.Tensor
    input_lengths: torch.Tensor
    cross_weights_flat: torch.Tensor
    cross_src_index: torch.Tensor
    cross_mask_flat: torch.Tensor
    triangle_terms: tuple[torch.Tensor, torch.Tensor, torch.Tensor] | None
    coarsening: torch.Tensor
    anchors: torch.Tensor
    relation_matrix: torch.Tensor


class AAMHGModel(nn.Module):
    """Reference implementation of the AAM-HG pipeline."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__()
        self.cfg = cfg
        self.modalities: list[str] = list(cfg.get("modalities", ["acoustic", "vibration", "electromagnetic"]))
        self.symbol_vocab = list(cfg.get("symbol_vocab", list(range(10))))
        node_dim = int(cfg.get("node_dim", 128))
        feature_dim = node_dim
        scale_count = len(cfg.get("candidate_scales", [16, 32, 64, 128]))
        scale_embed_dim = int(cfg.get("scale_aggregation", {}).get("scale_embed_dim", 32))
        modality_embed_dim = node_dim
        cross_max_degree = int(cfg.get("cross_modal_topk", 8))
        anchor_count = int(cfg.get("action_anchor_num", 16))
        gating_hidden_dim = int(cfg.get("gating_hidden_dim", 64))

        encoder_kwargs = {
            "out_dim": feature_dim,
            "conv_channels": tuple(cfg.get("modal_encoder", {}).get("conv_channels", (32, 64, 128))),
            "kernel_size": int(cfg.get("modal_encoder", {}).get("kernel_size", 5)),
            "dropout": float(cfg.get("modal_encoder", {}).get("dropout", 0.1)),
        }
        self.encoder_bank = ModalEncoderBank(self.modalities, encoder_kwargs)
        self.scale_aggregation = ScaleAdaptiveAggregator(
            modalities=self.modalities,
            feature_dim=feature_dim,
            scale_count=scale_count,
            scale_embed_dim=scale_embed_dim,
        )
        self.candidate_builder = CandidateNodeBuilder(feature_dim=feature_dim, modalities=self.modalities)
        self.node_embedding = NodeEmbedding(
            feature_dim=feature_dim,
            node_dim=node_dim,
            modalities=self.modalities,
            scale_count=scale_count,
            scale_embed_dim=scale_embed_dim,
        )
        self.delay_prior = DelayPrior(num_modalities=len(self.modalities))
        self.graph_construction = GraphConstruction(
            modalities=self.modalities,
            node_dim=node_dim,
            modality_embed_dim=modality_embed_dim,
            delay_prior=self.delay_prior,
            cross_max_degree=cross_max_degree,
        )
        self.gating = TemporalGating(
            node_dim=node_dim,
            hidden_dim=gating_hidden_dim,
            scale_embed_dim=scale_embed_dim,
        )
        self.gnn_layers = nn.ModuleList(
            [
                RelationAwareGNNLayer(node_dim=node_dim, modalities=self.modalities, gating=self.gating)
                for _ in range(int(cfg.get("gnn_layers", 3)))
            ]
        )
        self.coarsening = GraphCoarsening(
            node_dim=node_dim,
            anchor_count=anchor_count,
            anchor_window=float(cfg.get("graph_coarsening", {}).get("anchor_window", 96.0)),
        )
        self.action_relation = ActionRelationProjection()
        decoder_cfg = cfg.get("ordered_decoder", {})
        self.ordered_decoder = OrderedDecoder(
            node_dim=node_dim,
            hidden_dim=int(decoder_cfg.get("hidden_dim", node_dim)),
            omega_init=float(decoder_cfg.get("decay_omega", 1.0)),
        )
        ablation = cfg.get("ablation", {})
        self.use_temporal_gating = bool(ablation.get("use_temporal_gating", True))
        self.use_graph_coarsening = bool(ablation.get("use_graph_coarsening", True))
        self.use_relation_decoder = bool(ablation.get("use_relation_decoder", True))
        self.ctc_head = CTCHead(hidden_dim=self.ordered_decoder.hidden_dim, num_symbols=len(self.symbol_vocab) + 1)

    def _modal_path(
        self,
        modality: str,
        signal: torch.Tensor,
        anchors: torch.Tensor,
        scales: torch.Tensor,
        scale_indices: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        """Encode one modality.

        Args:
            modality: modality name.
            signal: ``[B, T]`` raw signal.
            anchors: ``[B, N]`` anchor timestamps (in samples).
            scales: ``[B, N]`` scale id per candidate (index into ``scale_indices``).
            scale_indices: ``[S]`` length of frames in samples per scale id.
        """
        b, t = signal.shape
        n = anchors.size(1)
        s_count = scale_indices.size(0)
        frames = signal.new_zeros(b, n, s_count, int(scale_indices.max().item()))
        max_r = int(scale_indices.max().item())
        for s_idx in range(s_count):
            r = int(scale_indices[s_idx].item())
            half = r // 2
            for sample in range(b):
                for i in range(n):
                    center = int(anchors[sample, i].item())
                    start = max(0, center - half)
                    end = min(t, start + r)
                    start = max(0, end - r)
                    chunk = signal[sample, start:end]
                    if chunk.numel() < r:
                        chunk = torch.nn.functional.pad(chunk, (0, r - chunk.numel()))
                    frames[sample, i, s_idx, :r] = chunk
        encoded_per_scale = []
        for s_idx in range(s_count):
            r = int(scale_indices[s_idx].item())
            view = frames[:, :, s_idx, :r].reshape(b * n, r)
            feats = self.encoder_bank.encode(modality, view)
            encoded_per_scale.append(feats.view(b, n, -1))
        h_stack = torch.stack(encoded_per_scale, dim=2)
        scale_ids = torch.arange(s_count, device=signal.device)
        u_im = self.scale_aggregation(modality, h_stack, scale_ids)
        candidate = self.candidate_builder(modality, u_im, anchors.float(), scales)
        z0 = self.node_embedding(u_im, anchors.float(), scales, modality_id=candidate.modality_id)
        return {"z": z0, "t": anchors.float(), "s": scales, "o": candidate.actionness, "u": u_im}

    def forward(self, batch: dict[str, Any]) -> AAMHGOutputs:
        """Run the full pipeline on ``batch``.

        ``batch`` keys:
            signals: dict modality -> ``[B, T_m]``
            anchors: dict modality -> ``[B, N_m]`` integer sample indices
            scales: dict modality -> ``[B, N_m]`` integer scale ids
            scale_indices: ``[S]`` frame length per scale id (samples)
        """
        per_modality_raw: dict[str, dict[str, torch.Tensor]] = {}
        for modality in self.modalities:
            per_modality_raw[modality] = self._modal_path(
                modality=modality,
                signal=batch["signals"][modality],
                anchors=batch["anchors"][modality],
                scales=batch["scales"][modality],
                scale_indices=batch["scale_indices"],
            )

        graph_state = self.graph_construction(
            {m: {"z": pack["z"], "t": pack["t"], "s": pack["s"], "o": pack["o"]} for m, pack in per_modality_raw.items()}
        )

        scales_embed = self.node_embedding.scale_embedding(graph_state.scales)
        for layer in self.gnn_layers:
            graph_state = layer(graph_state, scales_embed=scales_embed, use_gating=self.use_temporal_gating)

        triangle_terms = extract_triangle_terms(graph_state)

        cross_summary = torch.zeros_like(graph_state.actionness)
        for (mod_m, _), alpha in graph_state.cross_weights.items():
            sl = graph_state.modality_slices[mod_m]
            cross_summary[:, sl] = cross_summary[:, sl] + alpha.sum(dim=-1)

        if self.use_graph_coarsening:
            c, s_actions, tau = self.coarsening(
                z=graph_state.z,
                timestamps=graph_state.timestamps,
                actionness=graph_state.actionness,
                cross_weights_summary=cross_summary,
            )
        else:
            k_actions = self.coarsening.anchor_count
            tau = torch.linspace(0.0, 1.0, k_actions, device=graph_state.z.device).unsqueeze(0).expand(graph_state.z.size(0), -1)
            pooled = graph_state.z.mean(dim=1, keepdim=True).expand(-1, k_actions, -1)
            s_actions = pooled
            c = torch.zeros(graph_state.z.size(0), graph_state.z.size(1), k_actions, device=graph_state.z.device)

        if self.use_relation_decoder:
            r_node = build_node_relation_matrix(
                num_nodes=graph_state.z.size(1),
                intra_indices_per_modality=graph_state.intra_edges,
                modality_slices=graph_state.modality_slices,
                cross_weights=graph_state.cross_weights,
            )
            r_action = self.action_relation(c, r_node)
            hat_s = self.ordered_decoder(s_actions, tau, r_action)
        else:
            r_action = torch.zeros(s_actions.size(0), s_actions.size(1), s_actions.size(1), device=s_actions.device)
            hat_s = s_actions

        logits = self.ctc_head(hat_s)
        log_probs = self.ctc_head.to_log_probs(logits)
        input_lengths = torch.full((logits.size(0),), logits.size(1), dtype=torch.long, device=logits.device)

        cross_flat_values = []
        cross_flat_mask = []
        cross_flat_src = []
        for (mod_m, _), alpha in graph_state.cross_weights.items():
            mask = graph_state.cross_masks[(mod_m, _)]
            sl_m = graph_state.modality_slices[mod_m]
            b, n_m, n_n = alpha.shape
            src_idx = torch.arange(n_m, device=alpha.device).view(1, n_m, 1).expand(b, n_m, n_n) + sl_m.start
            cross_flat_values.append(alpha.reshape(-1))
            cross_flat_mask.append(mask.reshape(-1))
            cross_flat_src.append(src_idx.reshape(-1))
        if cross_flat_values:
            cross_values = torch.cat(cross_flat_values)
            cross_mask = torch.cat(cross_flat_mask)
            cross_src = torch.cat(cross_flat_src)
        else:
            cross_values = torch.zeros(0, device=logits.device)
            cross_mask = torch.zeros(0, dtype=torch.bool, device=logits.device)
            cross_src = torch.zeros(0, dtype=torch.long, device=logits.device)

        return AAMHGOutputs(
            log_probs=log_probs,
            input_lengths=input_lengths,
            cross_weights_flat=cross_values,
            cross_src_index=cross_src,
            cross_mask_flat=cross_mask,
            triangle_terms=triangle_terms,
            coarsening=c,
            anchors=tau,
            relation_matrix=r_action,
        )
