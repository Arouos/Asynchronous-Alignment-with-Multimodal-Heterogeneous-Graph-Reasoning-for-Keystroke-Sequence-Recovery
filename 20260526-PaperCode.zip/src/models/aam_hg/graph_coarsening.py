# Action-level graph coarsening.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch
import torch.nn as nn

from .node_embedding import SinusoidalTimeEncoding


class GraphCoarsening(nn.Module):
    r"""Learn soft assignment

    :math:`C_{ik} = \frac{\exp(\psi[z_i^{(L)}, p(t_i - \tau_k), o_i, \bar{a}_i])}
    {\sum_j \exp(\psi[\cdot])}`

    and produce action-level representations :math:`s_k = \sum_i C_{ik} z_i^{(L)}`.

    The anchor windows :math:`\Omega_k` are realised as a uniform partition of
    the candidate timeline; ``anchor_count`` controls :math:`K`.
    """

    def __init__(
        self,
        node_dim: int,
        anchor_count: int,
        anchor_window: float = 96.0,
        time_dim: int = 32,
        hidden_dim: int = 128,
    ) -> None:
        super().__init__()
        self.anchor_count = anchor_count
        self.anchor_window = anchor_window
        self.time_encoding = SinusoidalTimeEncoding(time_dim)
        feature_dim = node_dim + time_dim + 2
        self.psi = nn.Sequential(
            nn.Linear(feature_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(
        self,
        z: torch.Tensor,
        timestamps: torch.Tensor,
        actionness: torch.Tensor,
        cross_weights_summary: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Return ``(C, s, tau)``.

        Args:
            z: ``[B, V, D]`` node states.
            timestamps: ``[B, V]`` candidate times.
            actionness: ``[B, V]`` actionness ``o_i``.
            cross_weights_summary: ``[B, V]`` per-node aggregate ``\\bar{a}_i``.

        Returns:
            C: ``[B, V, K]`` soft assignment.
            s: ``[B, K, D]`` action-level representation.
            tau: ``[B, K]`` anchor times.
        """
        b, v, d = z.shape
        t_min = timestamps.min(dim=1, keepdim=True).values
        t_max = timestamps.max(dim=1, keepdim=True).values
        eps = 1.0e-6
        ratios = torch.linspace(0.5 / self.anchor_count, 1.0 - 0.5 / self.anchor_count, self.anchor_count, device=z.device)
        tau = t_min + ratios.unsqueeze(0) * (t_max - t_min + eps)

        delta = timestamps.unsqueeze(-1) - tau.unsqueeze(1)
        local_mask = delta.abs() <= self.anchor_window
        p_delta = self.time_encoding(delta)
        z_expand = z.unsqueeze(2).expand(b, v, self.anchor_count, d)
        o_expand = actionness.unsqueeze(-1).unsqueeze(-1).expand(b, v, self.anchor_count, 1)
        a_expand = cross_weights_summary.unsqueeze(-1).unsqueeze(-1).expand(b, v, self.anchor_count, 1)
        joint = torch.cat([z_expand, p_delta, o_expand, a_expand], dim=-1)
        logits = self.psi(joint).squeeze(-1)
        logits = logits.masked_fill(~local_mask, float("-inf"))
        denom_alive = local_mask.any(dim=1, keepdim=True)
        logits = torch.where(denom_alive.expand_as(logits), logits, torch.zeros_like(logits))
        c = logits.softmax(dim=1)
        c = torch.nan_to_num(c, nan=0.0)
        s = torch.einsum("bvk,bvd->bkd", c, z)
        return c, s, tau
