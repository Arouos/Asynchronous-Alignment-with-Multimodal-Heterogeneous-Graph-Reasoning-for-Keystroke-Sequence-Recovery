# Heterogeneous graph assembly :math:`\mathcal{G} = (V, E_{intra}, E_{cross})`.
# Author: Haoyu Qiang.

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn

from .cross_modal_matching import CrossModalMatcher
from .delay_prior import DelayPrior
from .intra_modal_edges import build_intra_modal_edges
from .sparsification import sparsify_cross_modal


@dataclass
class GraphState:
    """All graph state passed across GNN layers and into losses."""

    z: torch.Tensor                  # [B, V, D] concatenated node embeddings
    timestamps: torch.Tensor         # [B, V]
    modality_ids: torch.Tensor       # [B, V]
    scales: torch.Tensor             # [B, V]
    actionness: torch.Tensor         # [B, V]
    modality_slices: dict[str, slice]
    intra_edges: dict[str, torch.Tensor]               # modality -> [B, N_m, K_intra]
    cross_weights: dict[tuple[str, str], torch.Tensor]  # (m, n) -> [B, N_m, N_n]
    cross_masks: dict[tuple[str, str], torch.Tensor]   # (m, n) -> [B, N_m, N_n]


class GraphConstruction(nn.Module):
    """Assemble the heterogeneous graph from per-modality candidate batches."""

    def __init__(
        self,
        modalities: list[str],
        node_dim: int,
        modality_embed_dim: int,
        delay_prior: DelayPrior | None = None,
        intra_window_ms: float = 200.0,
        intra_max_neighbors: int = 6,
        cross_max_degree: int = 8,
    ) -> None:
        super().__init__()
        self.modalities = list(modalities)
        self.modality_ids = {name: idx for idx, name in enumerate(modalities)}
        self.intra_window_ms = float(intra_window_ms)
        self.intra_max_neighbors = int(intra_max_neighbors)
        self.cross_max_degree = int(cross_max_degree)
        self.delay_prior = delay_prior or DelayPrior(num_modalities=len(modalities))
        self.matcher = CrossModalMatcher(
            node_dim=node_dim,
            modality_embed_dim=modality_embed_dim,
            delay_prior=self.delay_prior,
            num_modalities=len(modalities),
        )

    def forward(self, per_modality: dict[str, dict[str, torch.Tensor]]) -> GraphState:
        z_list: list[torch.Tensor] = []
        t_list: list[torch.Tensor] = []
        m_list: list[torch.Tensor] = []
        s_list: list[torch.Tensor] = []
        a_list: list[torch.Tensor] = []
        slices: dict[str, slice] = {}
        intra: dict[str, torch.Tensor] = {}
        cursor = 0

        device = next(iter(per_modality.values()))["z"].device
        for modality in self.modalities:
            pack = per_modality[modality]
            z = pack["z"]
            t = pack["t"]
            s = pack["s"]
            o = pack["o"]
            n = z.size(1)
            z_list.append(z)
            t_list.append(t)
            s_list.append(s)
            a_list.append(o)
            modality_idx = torch.full_like(s, self.modality_ids[modality], dtype=torch.long)
            m_list.append(modality_idx)
            slices[modality] = slice(cursor, cursor + n)
            cursor += n
            intra[modality] = build_intra_modal_edges(t, self.intra_window_ms, self.intra_max_neighbors)

        z_cat = torch.cat(z_list, dim=1)
        t_cat = torch.cat(t_list, dim=1)
        m_cat = torch.cat(m_list, dim=1)
        s_cat = torch.cat(s_list, dim=1)
        a_cat = torch.cat(a_list, dim=1)

        cross_weights: dict[tuple[str, str], torch.Tensor] = {}
        cross_masks: dict[tuple[str, str], torch.Tensor] = {}
        for i_m, mod_m in enumerate(self.modalities):
            for j_n, mod_n in enumerate(self.modalities):
                if mod_m == mod_n:
                    continue
                pack_m = per_modality[mod_m]
                pack_n = per_modality[mod_n]
                soft = self.matcher(
                    z_m=pack_m["z"],
                    z_n=pack_n["z"],
                    t_m=pack_m["t"],
                    t_n=pack_n["t"],
                    o_m=pack_m["o"],
                    o_n=pack_n["o"],
                    m_id=self.modality_ids[mod_m],
                    n_id=self.modality_ids[mod_n],
                )
                sparse, mask = sparsify_cross_modal(soft, self.cross_max_degree)
                cross_weights[(mod_m, mod_n)] = sparse
                cross_masks[(mod_m, mod_n)] = mask

        _ = device
        return GraphState(
            z=z_cat,
            timestamps=t_cat,
            modality_ids=m_cat,
            scales=s_cat,
            actionness=a_cat,
            modality_slices=slices,
            intra_edges=intra,
            cross_weights=cross_weights,
            cross_masks=cross_masks,
        )
