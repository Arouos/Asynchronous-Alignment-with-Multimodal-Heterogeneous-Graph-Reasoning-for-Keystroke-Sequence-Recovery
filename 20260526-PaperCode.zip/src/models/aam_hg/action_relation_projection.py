# Projection of node-level relations to action-level relations.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch
import torch.nn as nn


def build_node_relation_matrix(
    num_nodes: int,
    intra_indices_per_modality: dict[str, torch.Tensor],
    modality_slices: dict[str, slice],
    cross_weights: dict[tuple[str, str], torch.Tensor],
) -> torch.Tensor:
    r"""Construct :math:`r_{ij}` on the full node set.

    :math:`r_{ij} = \mathbb{I}_{(i,j) \in E_{intra}} \eta_{ij}^{(L)}
    + \mathbb{I}_{(i,j) \in E_{cross}} \alpha_{ij} g_{ij}^{(L)}`.

    For simplicity the intra term uses a constant unit weight (the final-layer
    softmax has already been applied internally) and the cross term reuses the
    sparsified soft match.
    """
    sample_cross = next(iter(cross_weights.values())) if cross_weights else None
    batch_size = sample_cross.size(0) if sample_cross is not None else 1
    device = sample_cross.device if sample_cross is not None else torch.device("cpu")
    dtype = sample_cross.dtype if sample_cross is not None else torch.float32
    r = torch.zeros(batch_size, num_nodes, num_nodes, device=device, dtype=dtype)

    for modality, sl in modality_slices.items():
        edges = intra_indices_per_modality.get(modality)
        if edges is None or edges.numel() == 0:
            continue
        local_start = sl.start
        for sample in range(batch_size):
            for i_local in range(edges.size(1)):
                neighbors = edges[sample, i_local]
                for j_local in neighbors.tolist():
                    r[sample, local_start + i_local, local_start + j_local] = 1.0

    for (mod_m, mod_n), alpha in cross_weights.items():
        sl_m = modality_slices[mod_m]
        sl_n = modality_slices[mod_n]
        r[:, sl_m, sl_n] = r[:, sl_m, sl_n] + alpha
    return r


class ActionRelationProjection(nn.Module):
    r"""Compute :math:`R_{kq} = \frac{\sum_{i,j} C_{ik} C_{jq} r_{ij}}
    {\sum_{i,j} C_{ik} C_{jq} + \varepsilon}`.
    """

    def __init__(self, eps: float = 1.0e-6) -> None:
        super().__init__()
        self.eps = float(eps)

    def forward(self, c: torch.Tensor, r_node: torch.Tensor) -> torch.Tensor:
        numerator = torch.einsum("bvk,bvw,bwq->bkq", c, r_node, c)
        denom = torch.einsum("bvk,bwq->bkq", c, c) + self.eps
        return numerator / denom
