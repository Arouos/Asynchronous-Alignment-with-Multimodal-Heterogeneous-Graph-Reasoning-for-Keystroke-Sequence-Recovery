# Action candidate node assembly.
# Author: Haoyu Qiang.

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn


@dataclass
class CandidateBatch:
    """Container for per-modality candidate node properties.

    Attributes:
        features: ``[B, N_m, D]`` aggregated feature ``u_i^m``.
        timestamps: ``[B, N_m]`` anchor time ``t_i^m`` in milliseconds.
        scales: ``[B, N_m]`` integer scale id ``R_i``.
        actionness: ``[B, N_m]`` predicted ``o_i^m`` in ``[0, 1]``.
        modality_id: integer modality id ``m``.
    """

    features: torch.Tensor
    timestamps: torch.Tensor
    scales: torch.Tensor
    actionness: torch.Tensor
    modality_id: int


class CandidateNodeBuilder(nn.Module):
    """Predict the action-likelihood :math:`o_i^m` and assemble
    :math:`v_i^m = (u_i^m, t_i^m, R_i, o_i^m, m)` tuples for each modality.
    """

    def __init__(self, feature_dim: int, modalities: list[str]) -> None:
        super().__init__()
        self.modality_ids = {name: idx for idx, name in enumerate(modalities)}
        self.actionness_head = nn.Sequential(
            nn.Linear(feature_dim, feature_dim),
            nn.GELU(),
            nn.Linear(feature_dim, 1),
            nn.Sigmoid(),
        )

    def forward(
        self,
        modality: str,
        u_im: torch.Tensor,
        timestamps: torch.Tensor,
        scales: torch.Tensor,
    ) -> CandidateBatch:
        o_im = self.actionness_head(u_im).squeeze(-1)
        return CandidateBatch(
            features=u_im,
            timestamps=timestamps,
            scales=scales,
            actionness=o_im,
            modality_id=self.modality_ids[modality],
        )
