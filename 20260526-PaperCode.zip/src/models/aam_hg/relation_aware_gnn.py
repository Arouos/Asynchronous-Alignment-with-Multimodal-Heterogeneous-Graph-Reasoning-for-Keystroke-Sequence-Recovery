# Relation-aware graph neural network layer.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch
import torch.nn as nn

from .graph_construction import GraphState
from .temporal_gating import TemporalGating


class RelationAwareGNNLayer(nn.Module):
    r"""One layer of

    :math:`z_i^{(l+1)} = \mathrm{LN}(z_i^{(l)} +
    \sum_{j \in N_{intra}(i)} \eta_{ij}^l W_{intra} z_j^{(l)}
    + \sum_{j \in N_{cross}(i)} \beta_{ij}^l W_{cross} z_j^{(l)})`.

    The intra attention weight :math:`\eta_{ij}^l` is a softmax over intra
    neighbors of a dot-product score, while the cross weight
    :math:`\beta_{ij}^l = \mathrm{softmax}_j(\alpha_{ij} g_{ij}^{(l)})` is
    derived from the matcher score :math:`\alpha_{ij}` and the dynamic gate
    :math:`g_{ij}^{(l)}` produced by :class:`TemporalGating`.
    """

    def __init__(
        self,
        node_dim: int,
        modalities: list[str],
        gating: TemporalGating,
    ) -> None:
        super().__init__()
        self.modalities = list(modalities)
        self.W_intra = nn.Linear(node_dim, node_dim, bias=False)
        self.W_cross = nn.Linear(node_dim, node_dim, bias=False)
        self.W_intra_q = nn.Linear(node_dim, node_dim, bias=False)
        self.W_intra_k = nn.Linear(node_dim, node_dim, bias=False)
        self.norm = nn.LayerNorm(node_dim)
        self.gating = gating

    def _intra_message(
        self,
        z: torch.Tensor,
        timestamps: torch.Tensor,
        slices: dict[str, slice],
        intra_edges: dict[str, torch.Tensor],
    ) -> torch.Tensor:
        out = torch.zeros_like(z)
        b, v, d = z.shape
        for modality, sl in slices.items():
            edges = intra_edges[modality]
            if edges.size(-1) == 0:
                continue
            local_z = z[:, sl, :]
            local_t = timestamps[:, sl]
            n = local_z.size(1)
            local_z_q = self.W_intra_q(local_z)
            local_z_k = self.W_intra_k(local_z)
            gathered_k = torch.gather(
                local_z_k.unsqueeze(1).expand(b, n, n, d),
                2,
                edges.unsqueeze(-1).expand(b, n, edges.size(-1), d),
            )
            scores = torch.einsum("bnd,bnkd->bnk", local_z_q, gathered_k) / (d ** 0.5)
            weights = scores.softmax(dim=-1)
            gathered_v = torch.gather(
                self.W_intra(local_z).unsqueeze(1).expand(b, n, n, d),
                2,
                edges.unsqueeze(-1).expand(b, n, edges.size(-1), d),
            )
            message = (weights.unsqueeze(-1) * gathered_v).sum(dim=2)
            out[:, sl, :] = message
            _ = local_t
        return out

    def _cross_message(
        self,
        z: torch.Tensor,
        timestamps: torch.Tensor,
        scales_embed: torch.Tensor,
        slices: dict[str, slice],
        cross_weights: dict[tuple[str, str], torch.Tensor],
        cross_masks: dict[tuple[str, str], torch.Tensor],
        use_gating: bool,
    ) -> torch.Tensor:
        b, v, d = z.shape
        out = torch.zeros_like(z)
        for (mod_m, mod_n), alpha in cross_weights.items():
            mask = cross_masks[(mod_m, mod_n)]
            sl_m = slices[mod_m]
            sl_n = slices[mod_n]
            z_m = z[:, sl_m, :]
            z_n = z[:, sl_n, :]
            t_m = timestamps[:, sl_m]
            t_n = timestamps[:, sl_n]
            s_m = scales_embed[:, sl_m, :]
            s_n = scales_embed[:, sl_n, :]

            n_m = z_m.size(1)
            n_n = z_n.size(1)
            z_i = z_m.unsqueeze(2).expand(b, n_m, n_n, d)
            z_j = z_n.unsqueeze(1).expand(b, n_m, n_n, d)
            t_i = t_m.unsqueeze(2).expand(b, n_m, n_n)
            t_j = t_n.unsqueeze(1).expand(b, n_m, n_n)
            s_i_e = s_m.unsqueeze(2).expand(b, n_m, n_n, s_m.size(-1))
            s_j_e = s_n.unsqueeze(1).expand(b, n_m, n_n, s_n.size(-1))

            if use_gating:
                gates = self.gating(z_i, z_j, t_i, t_j, s_i_e, s_j_e)
            else:
                gates = torch.ones_like(alpha)
            logits = alpha * gates
            logits = logits.masked_fill(~mask, float("-inf"))
            beta = logits.softmax(dim=-1)
            beta = torch.nan_to_num(beta, nan=0.0)
            message = torch.einsum("bmn,bnd->bmd", beta, self.W_cross(z_n))
            out[:, sl_m, :] = out[:, sl_m, :] + message
        return out

    def forward(
        self,
        state: GraphState,
        scales_embed: torch.Tensor,
        use_gating: bool = True,
    ) -> GraphState:
        intra = self._intra_message(state.z, state.timestamps, state.modality_slices, state.intra_edges)
        cross = self._cross_message(
            state.z,
            state.timestamps,
            scales_embed,
            state.modality_slices,
            state.cross_weights,
            state.cross_masks,
            use_gating=use_gating,
        )
        updated = self.norm(state.z + intra + cross)
        return GraphState(
            z=updated,
            timestamps=state.timestamps,
            modality_ids=state.modality_ids,
            scales=state.scales,
            actionness=state.actionness,
            modality_slices=state.modality_slices,
            intra_edges=state.intra_edges,
            cross_weights=state.cross_weights,
            cross_masks=state.cross_masks,
        )
