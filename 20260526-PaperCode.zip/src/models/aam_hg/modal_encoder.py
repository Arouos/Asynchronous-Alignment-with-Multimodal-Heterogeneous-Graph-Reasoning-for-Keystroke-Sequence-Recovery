# Lightweight per-modality signal encoders.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch
import torch.nn as nn


class Modal1DEncoder(nn.Module):
    """Stack of 1D convolutions that turns a raw signal frame of length ``R``
    (the candidate scale) into a feature vector ``h_{i,s}^m`` of dimension
    ``out_dim``.
    """

    def __init__(
        self,
        in_channels: int = 1,
        conv_channels: tuple[int, ...] = (32, 64, 128),
        kernel_size: int = 5,
        out_dim: int = 128,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        layers: list[nn.Module] = []
        prev = in_channels
        for channels in conv_channels:
            layers.extend(
                [
                    nn.Conv1d(prev, channels, kernel_size=kernel_size, padding=kernel_size // 2),
                    nn.GELU(),
                    nn.Dropout(dropout),
                ]
            )
            prev = channels
        self.body = nn.Sequential(*layers)
        self.project = nn.Linear(prev, out_dim)

    def forward(self, frames: torch.Tensor) -> torch.Tensor:
        """Encode an input tensor of shape ``[N, R]`` into ``[N, out_dim]``."""
        if frames.dim() == 2:
            frames = frames.unsqueeze(1)
        features = self.body(frames)
        pooled = features.mean(dim=-1)
        return self.project(pooled)


class ModalEncoderBank(nn.Module):
    """Holds one :class:`Modal1DEncoder` per modality name."""

    def __init__(self, modalities: list[str], encoder_kwargs: dict | None = None) -> None:
        super().__init__()
        encoder_kwargs = encoder_kwargs or {}
        self.modalities = list(modalities)
        self.encoders = nn.ModuleDict(
            {name: Modal1DEncoder(**encoder_kwargs) for name in modalities}
        )

    def encode(self, modality: str, frames: torch.Tensor) -> torch.Tensor:
        return self.encoders[modality](frames)
