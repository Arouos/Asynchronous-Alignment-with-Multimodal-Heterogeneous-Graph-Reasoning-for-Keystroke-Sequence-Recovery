# Initial heterogeneous graph node embeddings.
# Author: Haoyu Qiang.

from __future__ import annotations

import math

import torch
import torch.nn as nn


class SinusoidalTimeEncoding(nn.Module):
    """Sinusoidal positional encoding for absolute or relative timestamps."""

    def __init__(self, dim: int, max_period: float = 1.0e4) -> None:
        super().__init__()
        if dim % 2 != 0:
            raise ValueError("Time encoding dimension must be even.")
        freqs = torch.exp(torch.arange(0, dim, 2).float() * (-math.log(max_period) / dim))
        self.register_buffer("inv_freqs", freqs)

    def forward(self, times: torch.Tensor) -> torch.Tensor:
        # times: [...]
        scaled = times.unsqueeze(-1) * self.inv_freqs
        return torch.cat([scaled.sin(), scaled.cos()], dim=-1)


class NodeEmbedding(nn.Module):
    r"""Compose initial node states
    :math:`z_i^{(0)} = W_h u_i^m + e_m + p(t_i^m) + p_s(R_i^m)`.
    """

    def __init__(
        self,
        feature_dim: int,
        node_dim: int,
        modalities: list[str],
        scale_count: int,
        scale_embed_dim: int = 32,
        time_dim: int | None = None,
    ) -> None:
        super().__init__()
        self.node_dim = node_dim
        self.W_h = nn.Linear(feature_dim, node_dim)
        self.modality_embedding = nn.Embedding(len(modalities), node_dim)
        self.scale_embedding = nn.Embedding(scale_count, scale_embed_dim)
        self.scale_project = nn.Linear(scale_embed_dim, node_dim)
        time_dim = time_dim or node_dim
        self.time_encoding = SinusoidalTimeEncoding(time_dim)
        self.time_project = nn.Linear(time_dim, node_dim)

    def forward(
        self,
        u_im: torch.Tensor,
        timestamps: torch.Tensor,
        scales: torch.Tensor,
        modality_id: int,
    ) -> torch.Tensor:
        modality_index = torch.full_like(scales, modality_id, dtype=torch.long)
        e_m = self.modality_embedding(modality_index)
        p_t = self.time_project(self.time_encoding(timestamps))
        p_s = self.scale_project(self.scale_embedding(scales))
        return self.W_h(u_im) + e_m + p_t + p_s
