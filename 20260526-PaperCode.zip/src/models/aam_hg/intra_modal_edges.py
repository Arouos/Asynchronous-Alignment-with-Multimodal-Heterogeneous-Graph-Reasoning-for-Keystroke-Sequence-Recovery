# Intra-modal temporal edge construction.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch


def build_intra_modal_edges(
    timestamps: torch.Tensor,
    window_ms: float,
    max_neighbors: int,
) -> torch.Tensor:
    """Construct ``E_intra`` as an index tensor of shape ``[B, N, K]``.

    For every candidate ``i`` the function returns the ``max_neighbors`` closest
    candidates in time (same modality, same sample).

    Args:
        timestamps: ``[B, N]`` candidate timestamps.
        window_ms: Half-window (in milliseconds) used to bound the neighborhood.
        max_neighbors: ``K``, the maximum number of intra-modal neighbors per node.
    """
    if timestamps.dim() != 2:
        raise ValueError("timestamps must have shape [B, N].")
    diff = (timestamps.unsqueeze(2) - timestamps.unsqueeze(1)).abs()
    within = diff <= window_ms
    diff = diff.masked_fill(~within, float("inf"))
    diff.diagonal(dim1=1, dim2=2).fill_(float("inf"))
    k_eff = min(max_neighbors, timestamps.size(1) - 1)
    if k_eff <= 0:
        return torch.zeros(timestamps.size(0), timestamps.size(1), 0, dtype=torch.long, device=timestamps.device)
    _, indices = diff.topk(k_eff, dim=-1, largest=False)
    return indices
