# Relation-enhanced ordered decoder.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch
import torch.nn as nn

from .node_embedding import SinusoidalTimeEncoding


class OrderedDecoder(nn.Module):
    r"""Decode action-level states into :math:`\hat{s}_k`.

    :math:`\hat{s}_k = \mathrm{GRU}(s_k, \hat{s}_{k-1}) +
    \sum_{q=1}^{K} \frac{\exp(R_{kq} + \omega p(\tau_k - \tau_q))}
    {\sum_r \exp(R_{kr} + \omega p(\tau_k - \tau_r))} W_R s_q`.
    """

    def __init__(
        self,
        node_dim: int,
        hidden_dim: int,
        time_dim: int = 32,
        omega_init: float = 1.0,
    ) -> None:
        super().__init__()
        self.gru_cell = nn.GRUCell(node_dim, hidden_dim)
        self.time_encoding = SinusoidalTimeEncoding(time_dim)
        self.time_project = nn.Linear(time_dim, 1)
        self.W_R = nn.Linear(node_dim, hidden_dim)
        self.omega = nn.Parameter(torch.tensor(omega_init))
        self.hidden_dim = hidden_dim

    def forward(
        self,
        s: torch.Tensor,
        tau: torch.Tensor,
        r_action: torch.Tensor,
    ) -> torch.Tensor:
        b, k, _ = s.shape
        h = torch.zeros(b, self.hidden_dim, device=s.device, dtype=s.dtype)
        outputs = []
        delta_tau = tau.unsqueeze(-1) - tau.unsqueeze(-2)
        time_bias = self.time_project(self.time_encoding(delta_tau)).squeeze(-1)
        logits = r_action + self.omega * time_bias
        weights = logits.softmax(dim=-1)
        relation_contrib = torch.einsum("bkq,bqd->bkd", weights, self.W_R(s))
        for step in range(k):
            h = self.gru_cell(s[:, step, :], h)
            outputs.append(h + relation_contrib[:, step, :])
        return torch.stack(outputs, dim=1)
