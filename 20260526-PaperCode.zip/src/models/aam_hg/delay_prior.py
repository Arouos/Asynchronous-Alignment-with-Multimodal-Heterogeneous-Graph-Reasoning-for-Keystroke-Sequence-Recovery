# Modal-pair delay prior :math:`\kappa_{m,n}`.
# Author: Haoyu Qiang.

from __future__ import annotations

import math

import torch
import torch.nn as nn


class DelayPrior(nn.Module):
    r"""Learnable kernel modelling the modal-pair delay prior.

    For an acoustic-vibration pair, for example, the prior peaks near the
    expected propagation delay.

    The kernel form is Gaussian:
    :math:`\kappa_{m,n}(\Delta t) = \exp(-(\Delta t - \mu_{m,n})^2 / (2 \sigma_{m,n}^2))`.
    """

    def __init__(self, num_modalities: int) -> None:
        super().__init__()
        self.num_modalities = num_modalities
        self.mu = nn.Parameter(torch.zeros(num_modalities, num_modalities))
        self.log_sigma = nn.Parameter(torch.zeros(num_modalities, num_modalities))

    def forward(self, m: int, n: int, delta_t: torch.Tensor) -> torch.Tensor:
        sigma = torch.exp(self.log_sigma[m, n]).clamp(min=1.0e-3)
        mu = self.mu[m, n]
        return torch.exp(-((delta_t - mu) ** 2) / (2.0 * sigma * sigma))

    def log_value(self, m: int, n: int, delta_t: torch.Tensor) -> torch.Tensor:
        sigma = torch.exp(self.log_sigma[m, n]).clamp(min=1.0e-3)
        mu = self.mu[m, n]
        return -((delta_t - mu) ** 2) / (2.0 * sigma * sigma) - sigma.log() - 0.5 * math.log(2.0 * math.pi)
