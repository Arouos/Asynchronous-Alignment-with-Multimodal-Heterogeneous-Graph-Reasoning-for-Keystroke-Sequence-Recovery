# AAM-HG model package.
# Author: Haoyu Qiang.

from .aam_hg_model import AAMHGModel

__all__ = ["AAMHGModel"]
