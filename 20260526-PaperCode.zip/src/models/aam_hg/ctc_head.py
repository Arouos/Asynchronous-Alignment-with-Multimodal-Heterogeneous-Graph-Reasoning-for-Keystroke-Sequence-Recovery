# CTC output head over the extended symbol alphabet.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class CTCHead(nn.Module):
    r"""Project ``\hat{s}_k`` to symbol log-probabilities

    :math:`P_k = \mathrm{Softmax}(W_y \hat{s}_k + b_y)` over
    :math:`\mathcal{Y} \cup \{\varnothing\}`.
    """

    def __init__(self, hidden_dim: int, num_symbols: int) -> None:
        super().__init__()
        self.linear = nn.Linear(hidden_dim, num_symbols)

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        logits = self.linear(hidden_states)
        return logits

    @staticmethod
    def to_log_probs(logits: torch.Tensor) -> torch.Tensor:
        """Convert logits ``[B, K, C]`` into CTC-compatible ``[K, B, C]`` log-probs."""
        log_probs = F.log_softmax(logits, dim=-1)
        return log_probs.transpose(0, 1)
