# Sparsification operator :math:`\Pi_{sp}` for cross-modal matches.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch


def sparsify_cross_modal(
    soft_matrix: torch.Tensor,
    max_degree: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Apply :math:`A^{m,n} = \\Pi_{sp}(\\tilde A^{m,n})`.

    Keeps the top ``max_degree`` outgoing edges per row, returning both the
    sparse weight matrix and a boolean mask of retained entries.

    Args:
        soft_matrix: ``[B, N_m, N_n]`` soft matches in ``[0, 1]``.
        max_degree: Maximum number of cross-modal neighbors per source node.
    """
    if soft_matrix.dim() != 3:
        raise ValueError("soft_matrix must have shape [B, N_m, N_n].")
    b, n_m, n_n = soft_matrix.shape
    k_eff = min(max_degree, n_n)
    if k_eff == 0:
        zero = torch.zeros_like(soft_matrix)
        return zero, zero.bool()
    values, indices = soft_matrix.topk(k_eff, dim=-1)
    mask = torch.zeros_like(soft_matrix, dtype=torch.bool)
    mask.scatter_(2, indices, True)
    sparse = soft_matrix * mask.to(soft_matrix.dtype)
    return sparse, mask
