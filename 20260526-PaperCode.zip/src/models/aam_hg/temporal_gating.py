# Dynamic temporal gating used in cross-modal message passing.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch
import torch.nn as nn

from .node_embedding import SinusoidalTimeEncoding


class TemporalGating(nn.Module):
    r"""Compute :math:`g_{ij}^{(l)} = \sigma(w_g^\top \tanh(W_i z_i^{(l)} + W_j z_j^{(l)}
    + W_\Delta p(t_i - t_j) + W_s p_s(s_i, s_j)))`.

    The scale pair is encoded by averaging the two endpoint scale embeddings.
    """

    def __init__(self, node_dim: int, hidden_dim: int, scale_embed_dim: int, time_dim: int = 32) -> None:
        super().__init__()
        self.W_i = nn.Linear(node_dim, hidden_dim, bias=False)
        self.W_j = nn.Linear(node_dim, hidden_dim, bias=False)
        self.W_delta = nn.Linear(time_dim, hidden_dim, bias=False)
        self.W_scale = nn.Linear(scale_embed_dim, hidden_dim, bias=False)
        self.time_encoding = SinusoidalTimeEncoding(time_dim)
        self.w_g = nn.Linear(hidden_dim, 1, bias=False)

    def forward(
        self,
        z_i: torch.Tensor,
        z_j: torch.Tensor,
        t_i: torch.Tensor,
        t_j: torch.Tensor,
        s_i_embed: torch.Tensor,
        s_j_embed: torch.Tensor,
    ) -> torch.Tensor:
        scale_pair = 0.5 * (s_i_embed + s_j_embed)
        delta_t = t_i - t_j
        p_dt = self.time_encoding(delta_t)
        h = torch.tanh(self.W_i(z_i) + self.W_j(z_j) + self.W_delta(p_dt) + self.W_scale(scale_pair))
        return torch.sigmoid(self.w_g(h).squeeze(-1))
