# Cross-modal soft matching with delay prior.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch
import torch.nn as nn

from .delay_prior import DelayPrior
from .node_embedding import SinusoidalTimeEncoding


class CrossModalMatcher(nn.Module):
    r"""Compute :math:`\tilde{a}_{ij}^{m,n}`.

    :math:`\tilde{a}_{ij}^{m,n} = \sigma( \phi[z_i^{(0)}, z_j^{(0)},
    p(t_i^m - t_j^n), e_m, e_n, o_i^m, o_j^n] + \gamma \log \kappa_{m,n}(t_i^m - t_j^n))`.
    """

    def __init__(
        self,
        node_dim: int,
        modality_embed_dim: int,
        delay_prior: DelayPrior,
        num_modalities: int,
        time_dim: int = 32,
        hidden_dim: int = 128,
        gamma_init: float = 1.0,
    ) -> None:
        super().__init__()
        self.delay_prior = delay_prior
        self.modality_embedding = nn.Embedding(num_modalities, modality_embed_dim)
        self.time_encoding = SinusoidalTimeEncoding(time_dim)
        feature_dim = 2 * node_dim + time_dim + 2 * modality_embed_dim + 2
        self.phi = nn.Sequential(
            nn.Linear(feature_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )
        self.gamma = nn.Parameter(torch.tensor(gamma_init))

    def forward(
        self,
        z_m: torch.Tensor,
        z_n: torch.Tensor,
        t_m: torch.Tensor,
        t_n: torch.Tensor,
        o_m: torch.Tensor,
        o_n: torch.Tensor,
        m_id: int,
        n_id: int,
    ) -> torch.Tensor:
        b, n_m, d = z_m.shape
        _, n_n, _ = z_n.shape

        z_i = z_m.unsqueeze(2).expand(b, n_m, n_n, d)
        z_j = z_n.unsqueeze(1).expand(b, n_m, n_n, d)
        delta_t = t_m.unsqueeze(2) - t_n.unsqueeze(1)
        p_dt = self.time_encoding(delta_t)
        e_m = self.modality_embedding(torch.tensor(m_id, device=z_m.device))
        e_n = self.modality_embedding(torch.tensor(n_id, device=z_n.device))
        e_m_b = e_m.view(1, 1, 1, -1).expand(b, n_m, n_n, -1)
        e_n_b = e_n.view(1, 1, 1, -1).expand(b, n_m, n_n, -1)
        o_i = o_m.unsqueeze(2).expand(b, n_m, n_n).unsqueeze(-1)
        o_j = o_n.unsqueeze(1).expand(b, n_m, n_n).unsqueeze(-1)

        joint = torch.cat([z_i, z_j, p_dt, e_m_b, e_n_b, o_i, o_j], dim=-1)
        logits = self.phi(joint).squeeze(-1)
        log_kappa = self.delay_prior.log_value(m_id, n_id, delta_t)
        return torch.sigmoid(logits + self.gamma * log_kappa)
