# Scale-adaptive aggregation of multi-scale action evidence.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch
import torch.nn as nn


class ScaleAdaptiveAggregator(nn.Module):
    r"""Aggregate multi-scale evidence per modality.

    Implements
    :math:`u_i^m = \sum_{s \in \mathcal{S}}
    \frac{\exp(q_m^\top \tanh(W_h h_{i,s}^m + W_s p_s(s)))}
    {\sum_{s'} \exp(\cdot)} h_{i,s}^m`.

    Inputs:
        features: ``[B, N, S, D]`` where ``S`` is the candidate scale count.
        scale_indices: ``[S]`` of integer scale ids used to index ``p_s``.
    """

    def __init__(
        self,
        modalities: list[str],
        feature_dim: int,
        scale_count: int,
        scale_embed_dim: int = 32,
    ) -> None:
        super().__init__()
        self.scale_embedding = nn.Embedding(scale_count, scale_embed_dim)
        self.W_h = nn.Linear(feature_dim, feature_dim, bias=False)
        self.W_s = nn.Linear(scale_embed_dim, feature_dim, bias=False)
        self.modal_queries = nn.ParameterDict(
            {name: nn.Parameter(torch.randn(feature_dim) * 0.02) for name in modalities}
        )

    def forward(self, modality: str, features: torch.Tensor, scale_indices: torch.Tensor) -> torch.Tensor:
        if features.dim() != 4:
            raise ValueError("features must have shape [B, N, S, D].")
        q_m = self.modal_queries[modality]
        s_embed = self.scale_embedding(scale_indices)
        attn_input = torch.tanh(self.W_h(features) + self.W_s(s_embed))
        logits = torch.einsum("bnsd,d->bns", attn_input, q_m)
        weights = logits.softmax(dim=-1).unsqueeze(-1)
        return (weights * features).sum(dim=-2)
