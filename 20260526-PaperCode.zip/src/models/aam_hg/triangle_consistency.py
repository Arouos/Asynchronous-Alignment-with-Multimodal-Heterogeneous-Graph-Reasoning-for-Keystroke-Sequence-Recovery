# Extraction of triangle terms over the three modalities.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch

from .graph_construction import GraphState


def extract_triangle_terms(
    state: GraphState,
    acoustic: str = "acoustic",
    vibration: str = "vibration",
    electromagnetic: str = "electromagnetic",
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor] | None:
    """Return ``(A^{a,v}, A^{v,e}, A^{a,e})`` collapsed across the batch.

    The matrices are stacked as ``[B*N_x, N_y]`` so the consistency loss can
    multiply ``A^{a,v}`` and ``A^{v,e}`` straightforwardly.
    """
    pair_av = (acoustic, vibration)
    pair_ve = (vibration, electromagnetic)
    pair_ae = (acoustic, electromagnetic)
    if pair_av not in state.cross_weights or pair_ve not in state.cross_weights or pair_ae not in state.cross_weights:
        return None
    a_av = state.cross_weights[pair_av]
    a_ve = state.cross_weights[pair_ve]
    a_ae = state.cross_weights[pair_ae]
    return a_av.flatten(0, 0), a_ve.flatten(0, 0), a_ae.flatten(0, 0)
