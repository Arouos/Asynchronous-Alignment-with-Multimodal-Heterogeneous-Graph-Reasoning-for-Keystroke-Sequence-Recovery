# Multi-modal mixture-of-experts JEPA baseline.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from ..aam_hg.ctc_head import CTCHead
from ..aam_hg.modal_encoder import Modal1DEncoder


class M3JEPAModel(nn.Module):
    """Mixture-of-experts JEPA baseline."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__()
        self.modalities = list(cfg.get("modalities", ["acoustic", "vibration", "electromagnetic"]))
        encoder_dim = int(cfg.get("encoder_dim", 128))
        expert_dim = int(cfg.get("expert_dim", 96))
        num_experts = int(cfg.get("num_experts", 4))
        self.encoders = nn.ModuleDict({m: Modal1DEncoder(out_dim=encoder_dim) for m in self.modalities})
        self.experts = nn.ModuleList([nn.Linear(encoder_dim, expert_dim) for _ in range(num_experts)])
        self.gate = nn.Linear(encoder_dim, num_experts)
        self.predictor = nn.Linear(expert_dim, expert_dim)
        symbol_vocab = list(cfg.get("symbol_vocab", list(range(10))))
        self.head = CTCHead(hidden_dim=expert_dim, num_symbols=len(symbol_vocab) + 1)

    def _encode(self, batch: dict[str, Any]) -> tuple[torch.Tensor, int]:
        b = next(iter(batch["signals"].values())).size(0)
        feats: list[torch.Tensor] = []
        for modality in self.modalities:
            anchors = batch["anchors"][modality]
            signal = batch["signals"][modality]
            n = anchors.size(1)
            seq = signal.new_zeros(b, n, signal.size(-1))
            for i in range(n):
                seq[:, i, :] = signal
            encoded = self.encoders[modality](seq.reshape(b * n, -1)).view(b, n, -1)
            feats.append(encoded)
        return torch.stack(feats, dim=0).mean(dim=0), b

    def forward(self, batch: dict[str, Any]) -> dict[str, torch.Tensor]:
        features, b = self._encode(batch)
        gates = self.gate(features).softmax(dim=-1)
        expert_outputs = torch.stack([expert(features) for expert in self.experts], dim=-2)
        mixed = (gates.unsqueeze(-1) * expert_outputs).sum(dim=-2)
        predicted = self.predictor(mixed)
        logits = self.head(predicted)
        return {
            "log_probs": self.head.to_log_probs(logits),
            "input_lengths": torch.full((b,), logits.size(1), dtype=torch.long, device=logits.device),
        }
