# Practical acoustic side-channel attack baseline.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from ..aam_hg.ctc_head import CTCHead


class PracticalASCAModel(nn.Module):
    """Conv-RNN baseline operating on the acoustic modality."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__()
        conv_channels = tuple(cfg.get("conv_channels", (32, 64, 128)))
        layers: list[nn.Module] = []
        prev = 1
        for channels in conv_channels:
            layers.extend([nn.Conv1d(prev, channels, kernel_size=5, padding=2), nn.GELU()])
            prev = channels
        self.conv = nn.Sequential(*layers)
        hidden = int(cfg.get("recurrent_hidden", 128))
        self.rnn = nn.GRU(prev, hidden, batch_first=True, bidirectional=True)
        symbol_vocab = list(cfg.get("symbol_vocab", list(range(10))))
        self.head = CTCHead(hidden_dim=hidden * 2, num_symbols=len(symbol_vocab) + 1)

    def forward(self, batch: dict[str, Any]) -> dict[str, torch.Tensor]:
        signal = batch["signals"]["acoustic"]
        b = signal.size(0)
        features = self.conv(signal.unsqueeze(1))
        features = features.transpose(1, 2)
        rnn_out, _ = self.rnn(features)
        logits = self.head(rnn_out)
        return {
            "log_probs": self.head.to_log_probs(logits),
            "input_lengths": torch.full((b,), logits.size(1), dtype=torch.long, device=logits.device),
        }
