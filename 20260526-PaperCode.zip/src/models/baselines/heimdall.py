# Heimdall acoustic-emanation keystroke inference baseline.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from ..aam_hg.ctc_head import CTCHead
from ..aam_hg.modal_encoder import Modal1DEncoder


class HeimdallModel(nn.Module):
    """Acoustic-only encoder + GRU + CTC head."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__()
        encoder_dim = int(cfg.get("encoder_dim", 128))
        recurrent_hidden = int(cfg.get("recurrent_hidden", 128))
        self.encoder = Modal1DEncoder(out_dim=encoder_dim)
        self.rnn = nn.GRU(encoder_dim, recurrent_hidden, batch_first=True, bidirectional=True)
        symbol_vocab = list(cfg.get("symbol_vocab", list(range(10))))
        self.head = CTCHead(hidden_dim=recurrent_hidden * 2, num_symbols=len(symbol_vocab) + 1)

    def forward(self, batch: dict[str, Any]) -> dict[str, torch.Tensor]:
        signal = batch["signals"]["acoustic"]
        anchors = batch["anchors"]["acoustic"]
        b = signal.size(0)
        n = anchors.size(1)
        seq = signal.new_zeros(b, n, signal.size(-1))
        for i in range(n):
            seq[:, i, :] = signal
        features = self.encoder(seq.reshape(b * n, -1)).view(b, n, -1)
        rnn_out, _ = self.rnn(features)
        logits = self.head(rnn_out)
        return {
            "log_probs": self.head.to_log_probs(logits),
            "input_lengths": torch.full((b,), logits.size(1), dtype=torch.long, device=logits.device),
        }
