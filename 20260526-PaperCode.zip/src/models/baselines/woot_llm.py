# Spectral post-processing with LLM-style correction baseline.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from ..aam_hg.ctc_head import CTCHead


class WOOTLLMModel(nn.Module):
    """Spectral + transformer baseline."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__()
        spectral_dim = int(cfg.get("spectral_dim", 128))
        self.spectral = nn.Sequential(
            nn.Conv1d(1, spectral_dim, kernel_size=9, stride=4, padding=4),
            nn.GELU(),
            nn.Conv1d(spectral_dim, spectral_dim, kernel_size=5, stride=2, padding=2),
            nn.GELU(),
        )
        layer = nn.TransformerEncoderLayer(
            d_model=spectral_dim,
            nhead=int(cfg.get("lm_heads", 4)),
            dim_feedforward=int(cfg.get("lm_hidden", 128)) * 2,
            batch_first=True,
        )
        self.lm = nn.TransformerEncoder(layer, num_layers=int(cfg.get("lm_layers", 2)))
        symbol_vocab = list(cfg.get("symbol_vocab", list(range(10))))
        self.head = CTCHead(hidden_dim=spectral_dim, num_symbols=len(symbol_vocab) + 1)

    def forward(self, batch: dict[str, Any]) -> dict[str, torch.Tensor]:
        signal = batch["signals"]["acoustic"]
        b = signal.size(0)
        x = self.spectral(signal.unsqueeze(1)).transpose(1, 2)
        x = self.lm(x)
        logits = self.head(x)
        return {
            "log_probs": self.head.to_log_probs(logits),
            "input_lengths": torch.full((b,), logits.size(1), dtype=torch.long, device=logits.device),
        }
