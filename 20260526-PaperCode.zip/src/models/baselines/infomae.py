# Pair-efficient masked autoencoder (InfoMAE) baseline.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from ..aam_hg.ctc_head import CTCHead
from ..aam_hg.modal_encoder import Modal1DEncoder


class InfoMAEModel(nn.Module):
    """Pair-efficient masked autoencoder baseline."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__()
        self.modalities = list(cfg.get("modalities", ["acoustic", "vibration", "electromagnetic"]))
        encoder_dim = int(cfg.get("encoder_dim", 128))
        proj_dim = int(cfg.get("projection_dim", 64))
        self.mask_ratio = float(cfg.get("mask_ratio", 0.5))
        self.encoders = nn.ModuleDict({m: Modal1DEncoder(out_dim=encoder_dim) for m in self.modalities})
        self.projectors = nn.ModuleDict({m: nn.Linear(encoder_dim, proj_dim) for m in self.modalities})
        self.temperature = nn.Parameter(torch.tensor(float(cfg.get("mi_temperature", 0.07))))
        symbol_vocab = list(cfg.get("symbol_vocab", list(range(10))))
        self.head = CTCHead(hidden_dim=proj_dim, num_symbols=len(symbol_vocab) + 1)

    def forward(self, batch: dict[str, Any]) -> dict[str, torch.Tensor]:
        b = next(iter(batch["signals"].values())).size(0)
        projections = []
        for modality in self.modalities:
            anchors = batch["anchors"][modality]
            signal = batch["signals"][modality]
            n = anchors.size(1)
            seq = signal.new_zeros(b, n, signal.size(-1))
            for i in range(n):
                seq[:, i, :] = signal
            features = self.encoders[modality](seq.reshape(b * n, -1)).view(b, n, -1)
            mask = (torch.rand_like(features[..., :1]) > self.mask_ratio).to(features.dtype)
            features = features * mask
            projections.append(self.projectors[modality](features))
        fused = torch.stack(projections, dim=0).mean(dim=0)
        logits = self.head(fused)
        _ = self.temperature
        return {
            "log_probs": self.head.to_log_probs(logits),
            "input_lengths": torch.full((b,), logits.size(1), dtype=torch.long, device=logits.device),
        }
