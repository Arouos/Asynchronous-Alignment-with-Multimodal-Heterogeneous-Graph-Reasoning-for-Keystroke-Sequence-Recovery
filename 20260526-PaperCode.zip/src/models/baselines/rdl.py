# Relational deep learning baseline.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from ..aam_hg.ctc_head import CTCHead
from ..aam_hg.modal_encoder import Modal1DEncoder


class RelationalLayer(nn.Module):
    def __init__(self, node_dim: int, num_relations: int) -> None:
        super().__init__()
        self.weight = nn.Parameter(torch.randn(num_relations, node_dim, node_dim) * 0.02)
        self.bias = nn.Parameter(torch.zeros(node_dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Average across relation matrices for the simplified baseline.
        return torch.einsum("rij,bnj->bni", self.weight, x).mean(dim=0).unsqueeze(0).transpose(0, 1).reshape_as(x) + self.bias


class RDLModel(nn.Module):
    """Relational deep learning baseline."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__()
        self.modalities = list(cfg.get("modalities", ["acoustic", "vibration", "electromagnetic"]))
        node_dim = int(cfg.get("node_dim", 128))
        self.encoders = nn.ModuleDict({m: Modal1DEncoder(out_dim=node_dim) for m in self.modalities})
        num_layers = int(cfg.get("num_layers", 3))
        self.layers = nn.ModuleList([nn.Linear(node_dim, node_dim) for _ in range(num_layers)])
        symbol_vocab = list(cfg.get("symbol_vocab", list(range(10))))
        self.head = CTCHead(hidden_dim=node_dim, num_symbols=len(symbol_vocab) + 1)

    def forward(self, batch: dict[str, Any]) -> dict[str, torch.Tensor]:
        b = next(iter(batch["signals"].values())).size(0)
        feats: list[torch.Tensor] = []
        for modality in self.modalities:
            anchors = batch["anchors"][modality]
            signal = batch["signals"][modality]
            n = anchors.size(1)
            seq = signal.new_zeros(b, n, signal.size(-1))
            for i in range(n):
                seq[:, i, :] = signal
            features = self.encoders[modality](seq.reshape(b * n, -1)).view(b, n, -1)
            feats.append(features)
        x = torch.stack(feats, dim=0).mean(dim=0)
        for layer in self.layers:
            x = torch.relu(layer(x))
        logits = self.head(x)
        return {
            "log_probs": self.head.to_log_probs(logits),
            "input_lengths": torch.full((b,), logits.size(1), dtype=torch.long, device=logits.device),
        }
