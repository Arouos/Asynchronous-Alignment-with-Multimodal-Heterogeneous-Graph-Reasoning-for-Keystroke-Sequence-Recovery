# Modality-exclusive and modality-shared learning (MEA) baseline.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from ..aam_hg.ctc_head import CTCHead
from ..aam_hg.modal_encoder import Modal1DEncoder


class MEAModel(nn.Module):
    """Modality-exclusive + modality-shared baseline."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__()
        self.modalities = list(cfg.get("modalities", ["acoustic", "vibration", "electromagnetic"]))
        encoder_dim = int(cfg.get("encoder_dim", 128))
        shared_dim = int(cfg.get("shared_dim", 64))
        exclusive_dim = int(cfg.get("exclusive_dim", 64))
        self.encoders = nn.ModuleDict({m: Modal1DEncoder(out_dim=encoder_dim) for m in self.modalities})
        self.shared = nn.Linear(encoder_dim, shared_dim)
        self.exclusive = nn.ModuleDict({m: nn.Linear(encoder_dim, exclusive_dim) for m in self.modalities})
        fused_dim = shared_dim + exclusive_dim
        symbol_vocab = list(cfg.get("symbol_vocab", list(range(10))))
        self.head = CTCHead(hidden_dim=fused_dim, num_symbols=len(symbol_vocab) + 1)

    def forward(self, batch: dict[str, Any]) -> dict[str, torch.Tensor]:
        b = next(iter(batch["signals"].values())).size(0)
        shared_list = []
        exclusive_list = []
        for modality in self.modalities:
            anchors = batch["anchors"][modality]
            signal = batch["signals"][modality]
            n = anchors.size(1)
            seq = signal.new_zeros(b, n, signal.size(-1))
            for i in range(n):
                seq[:, i, :] = signal
            features = self.encoders[modality](seq.reshape(b * n, -1)).view(b, n, -1)
            shared_list.append(self.shared(features))
            exclusive_list.append(self.exclusive[modality](features))
        shared = torch.stack(shared_list, dim=0).mean(dim=0)
        exclusive = torch.stack(exclusive_list, dim=0).mean(dim=0)
        fused = torch.cat([shared, exclusive], dim=-1)
        logits = self.head(fused)
        return {
            "log_probs": self.head.to_log_probs(logits),
            "input_lengths": torch.full((b,), logits.size(1), dtype=torch.long, device=logits.device),
        }
