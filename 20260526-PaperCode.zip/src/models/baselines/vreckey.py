# Vibration-as-infrared keystroke recovery baseline.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from ..aam_hg.ctc_head import CTCHead
from ..aam_hg.modal_encoder import Modal1DEncoder


class VRecKeyModel(nn.Module):
    """Acoustic + vibration two-modality baseline."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__()
        self.modalities = list(cfg.get("modalities", ["acoustic", "vibration"]))
        encoder_dim = int(cfg.get("encoder_dim", 128))
        fusion_dim = int(cfg.get("fusion_dim", 128))
        self.encoders = nn.ModuleDict({m: Modal1DEncoder(out_dim=encoder_dim) for m in self.modalities})
        self.fuser = nn.Linear(encoder_dim * len(self.modalities), fusion_dim)
        symbol_vocab = list(cfg.get("symbol_vocab", list(range(10))))
        self.head = CTCHead(hidden_dim=fusion_dim, num_symbols=len(symbol_vocab) + 1)

    def forward(self, batch: dict[str, Any]) -> dict[str, torch.Tensor]:
        b = next(iter(batch["signals"].values())).size(0)
        feats = []
        for modality in self.modalities:
            anchors = batch["anchors"][modality]
            signal = batch["signals"][modality]
            n = anchors.size(1)
            seq = signal.new_zeros(b, n, signal.size(-1))
            for i in range(n):
                seq[:, i, :] = signal
            features = self.encoders[modality](seq.reshape(b * n, -1)).view(b, n, -1)
            feats.append(features)
        fused = self.fuser(torch.cat(feats, dim=-1))
        logits = self.head(fused)
        return {
            "log_probs": self.head.to_log_probs(logits),
            "input_lengths": torch.full((b,), logits.size(1), dtype=torch.long, device=logits.device),
        }
