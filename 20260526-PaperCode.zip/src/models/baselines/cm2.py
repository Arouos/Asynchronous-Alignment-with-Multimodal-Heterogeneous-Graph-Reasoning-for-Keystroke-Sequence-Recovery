# Coupled cross-modal variational alignment (CM2) baseline.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from ..aam_hg.ctc_head import CTCHead
from ..aam_hg.modal_encoder import Modal1DEncoder


class CM2Model(nn.Module):
    r"""Simplified CM2 baseline.

    Encodes each modality with a :class:`Modal1DEncoder`, computes a copula-style
    latent ``[\mu, \log\sigma]`` per modality, averages the latents, and feeds
    them through a CTC head.
    """

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__()
        self.modalities = list(cfg.get("modalities", ["acoustic", "vibration", "electromagnetic"]))
        encoder_dim = int(cfg.get("encoder_dim", 128))
        latent_dim = int(cfg.get("latent_dim", 64))
        copula_dim = int(cfg.get("copula_dim", 32))
        self.encoders = nn.ModuleDict({m: Modal1DEncoder(out_dim=encoder_dim) for m in self.modalities})
        self.mu_heads = nn.ModuleDict({m: nn.Linear(encoder_dim, latent_dim) for m in self.modalities})
        self.logsigma_heads = nn.ModuleDict({m: nn.Linear(encoder_dim, latent_dim) for m in self.modalities})
        self.copula = nn.Linear(latent_dim, copula_dim)
        symbol_vocab = list(cfg.get("symbol_vocab", list(range(10))))
        self.head = CTCHead(hidden_dim=copula_dim, num_symbols=len(symbol_vocab) + 1)

    def forward(self, batch: dict[str, Any]) -> dict[str, torch.Tensor]:
        b = next(iter(batch["signals"].values())).size(0)
        latents = []
        for modality in self.modalities:
            anchors = batch["anchors"][modality]
            signal = batch["signals"][modality]
            n = anchors.size(1)
            seq = signal.new_zeros(b, n, signal.size(-1))
            for i in range(n):
                seq[:, i, :] = signal
            features = self.encoders[modality](seq.reshape(b * n, -1)).view(b, n, -1)
            mu = self.mu_heads[modality](features)
            log_sigma = self.logsigma_heads[modality](features)
            latents.append(mu + log_sigma.tanh())
        z = torch.stack(latents, dim=0).mean(dim=0)
        copula = self.copula(z)
        logits = self.head(copula)
        return {
            "log_probs": self.head.to_log_probs(logits),
            "input_lengths": torch.full((b,), logits.size(1), dtype=torch.long, device=logits.device),
        }
