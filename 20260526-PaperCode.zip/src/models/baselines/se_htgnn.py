# Simple-and-efficient heterogeneous temporal GNN baseline.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from ..aam_hg.ctc_head import CTCHead
from ..aam_hg.modal_encoder import Modal1DEncoder


class SEHTGNNModel(nn.Module):
    """Per-modality temporal aggregation followed by heterogeneous fusion."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__()
        self.modalities = list(cfg.get("modalities", ["acoustic", "vibration", "electromagnetic"]))
        node_dim = int(cfg.get("node_dim", 128))
        self.encoders = nn.ModuleDict({m: Modal1DEncoder(out_dim=node_dim) for m in self.modalities})
        self.temporal_gru = nn.ModuleDict(
            {m: nn.GRU(node_dim, node_dim, batch_first=True, bidirectional=True) for m in self.modalities}
        )
        self.cross_proj = nn.Linear(node_dim * 2 * len(self.modalities), node_dim)
        symbol_vocab = list(cfg.get("symbol_vocab", list(range(10))))
        self.head = CTCHead(hidden_dim=node_dim, num_symbols=len(symbol_vocab) + 1)

    def forward(self, batch: dict[str, Any]) -> dict[str, torch.Tensor]:
        b = next(iter(batch["signals"].values())).size(0)
        feats: list[torch.Tensor] = []
        for modality in self.modalities:
            anchors = batch["anchors"][modality]
            signal = batch["signals"][modality]
            n = anchors.size(1)
            seq = signal.new_zeros(b, n, signal.size(-1))
            for i in range(n):
                seq[:, i, :] = signal
            encoded = self.encoders[modality](seq.reshape(b * n, -1)).view(b, n, -1)
            out, _ = self.temporal_gru[modality](encoded)
            feats.append(out)
        merged = torch.cat(feats, dim=-1)
        fused = self.cross_proj(merged)
        logits = self.head(fused)
        return {
            "log_probs": self.head.to_log_probs(logits),
            "input_lengths": torch.full((b,), logits.size(1), dtype=torch.long, device=logits.device),
        }
