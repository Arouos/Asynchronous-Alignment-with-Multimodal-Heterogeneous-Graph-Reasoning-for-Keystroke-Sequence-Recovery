# Relation graph transformer baseline.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn

from ..aam_hg.ctc_head import CTCHead
from ..aam_hg.modal_encoder import Modal1DEncoder


class RGTModel(nn.Module):
    """Multi-head attention with edge-type embeddings."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        super().__init__()
        self.modalities = list(cfg.get("modalities", ["acoustic", "vibration", "electromagnetic"]))
        node_dim = int(cfg.get("node_dim", 128))
        num_heads = int(cfg.get("num_heads", 4))
        num_layers = int(cfg.get("num_layers", 3))
        edge_type_dim = int(cfg.get("edge_type_dim", 16))
        self.encoders = nn.ModuleDict({m: Modal1DEncoder(out_dim=node_dim) for m in self.modalities})
        self.edge_type_embed = nn.Embedding(len(self.modalities) ** 2, edge_type_dim)
        layer = nn.TransformerEncoderLayer(d_model=node_dim, nhead=num_heads, batch_first=True)
        self.transformer = nn.TransformerEncoder(layer, num_layers=num_layers)
        symbol_vocab = list(cfg.get("symbol_vocab", list(range(10))))
        self.head = CTCHead(hidden_dim=node_dim, num_symbols=len(symbol_vocab) + 1)

    def forward(self, batch: dict[str, Any]) -> dict[str, torch.Tensor]:
        b = next(iter(batch["signals"].values())).size(0)
        feats: list[torch.Tensor] = []
        for modality in self.modalities:
            anchors = batch["anchors"][modality]
            signal = batch["signals"][modality]
            n = anchors.size(1)
            seq = signal.new_zeros(b, n, signal.size(-1))
            for i in range(n):
                seq[:, i, :] = signal
            features = self.encoders[modality](seq.reshape(b * n, -1)).view(b, n, -1)
            feats.append(features)
        x = torch.cat(feats, dim=1)
        x = self.transformer(x)
        per_anchor = x[:, : feats[0].size(1), :]
        logits = self.head(per_anchor)
        _ = self.edge_type_embed
        return {
            "log_probs": self.head.to_log_probs(logits),
            "input_lengths": torch.full((b,), logits.size(1), dtype=torch.long, device=logits.device),
        }
