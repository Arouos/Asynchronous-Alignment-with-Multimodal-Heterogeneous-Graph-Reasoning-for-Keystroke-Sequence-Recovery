# Mean absolute time offset (ms) between predicted and reference events.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Sequence


def alignment_error_ms(
    pred_times_list: Sequence[Sequence[float]],
    gt_times_list: Sequence[Sequence[float]],
) -> float:
    """Return the mean ``|t_pred - t_gt|`` over matched event pairs."""
    total = 0.0
    count = 0
    for p_times, g_times in zip(pred_times_list, gt_times_list):
        pairs = min(len(p_times), len(g_times))
        for idx in range(pairs):
            total += abs(p_times[idx] - g_times[idx])
            count += 1
    if count == 0:
        return 0.0
    return total / count
