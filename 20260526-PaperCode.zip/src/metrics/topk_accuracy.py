# Top-k keystroke level accuracy.
# Author: Haoyu Qiang.

from __future__ import annotations

import torch


def topk_accuracy(logits: torch.Tensor, targets: torch.Tensor, k: int) -> float:
    """Compute the top-k accuracy on already-aligned keystroke predictions.

    Args:
        logits: Tensor ``[N, C]`` of class scores.
        targets: Tensor ``[N]`` of integer class targets.
        k: Top-k cut-off.
    """
    if logits.numel() == 0:
        return 0.0
    k_eff = min(k, logits.size(-1))
    _, indices = logits.topk(k_eff, dim=-1)
    matches = indices.eq(targets.unsqueeze(-1)).any(dim=-1)
    return float(matches.float().mean().item())
