# Keystroke-level F1 score with time matching.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Sequence


def _match_events(
    pred_times: Sequence[float],
    pred_labels: Sequence[int],
    gt_times: Sequence[float],
    gt_labels: Sequence[int],
    tolerance_ms: float,
) -> tuple[int, int, int]:
    """Greedy bipartite-style matching between predicted and ground-truth events."""
    used = [False] * len(gt_times)
    tp = 0
    for p_time, p_label in zip(pred_times, pred_labels):
        best_idx = -1
        best_dt = tolerance_ms
        for j, g_time in enumerate(gt_times):
            if used[j]:
                continue
            dt = abs(g_time - p_time)
            if dt <= best_dt and p_label == gt_labels[j]:
                best_dt = dt
                best_idx = j
        if best_idx >= 0:
            used[best_idx] = True
            tp += 1
    fp = len(pred_times) - tp
    fn = len(gt_times) - tp
    return tp, fp, fn


def keystroke_f1(
    pred_times_list: Sequence[Sequence[float]],
    pred_labels_list: Sequence[Sequence[int]],
    gt_times_list: Sequence[Sequence[float]],
    gt_labels_list: Sequence[Sequence[int]],
    tolerance_ms: float = 50.0,
) -> float:
    """Aggregate per-sample TP / FP / FN counts into a corpus F1."""
    tp_total = 0
    fp_total = 0
    fn_total = 0
    for p_t, p_l, g_t, g_l in zip(pred_times_list, pred_labels_list, gt_times_list, gt_labels_list):
        tp, fp, fn = _match_events(p_t, p_l, g_t, g_l, tolerance_ms)
        tp_total += tp
        fp_total += fp
        fn_total += fn
    precision = tp_total / max(tp_total + fp_total, 1)
    recall = tp_total / max(tp_total + fn_total, 1)
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)
