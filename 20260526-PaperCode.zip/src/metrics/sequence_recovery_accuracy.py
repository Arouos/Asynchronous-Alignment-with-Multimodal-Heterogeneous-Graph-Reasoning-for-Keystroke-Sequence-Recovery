# Sequence recovery accuracy (SRA) computation.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Iterable, Sequence


def sequence_recovery_accuracy(
    references: Iterable[Sequence[int]],
    hypotheses: Iterable[Sequence[int]],
) -> float:
    """Return the fraction of password sequences recovered exactly."""
    correct = 0
    total = 0
    for reference, hypothesis in zip(references, hypotheses):
        total += 1
        if list(reference) == list(hypothesis):
            correct += 1
    return correct / max(total, 1)
