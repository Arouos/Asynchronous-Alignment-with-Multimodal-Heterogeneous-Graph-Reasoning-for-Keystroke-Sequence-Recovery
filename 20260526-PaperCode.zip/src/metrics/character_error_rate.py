# Character error rate (CER) computation.
# Author: Haoyu Qiang.

from __future__ import annotations

from typing import Iterable, Sequence


def _levenshtein(reference: Sequence[int], hypothesis: Sequence[int]) -> int:
    """Standard Levenshtein edit distance with O(min(n,m)) memory."""
    if len(reference) < len(hypothesis):
        reference, hypothesis = hypothesis, reference
    if not hypothesis:
        return len(reference)

    previous = list(range(len(hypothesis) + 1))
    for i, ref_token in enumerate(reference, start=1):
        current = [i] + [0] * len(hypothesis)
        for j, hyp_token in enumerate(hypothesis, start=1):
            cost = 0 if ref_token == hyp_token else 1
            current[j] = min(
                previous[j] + 1,
                current[j - 1] + 1,
                previous[j - 1] + cost,
            )
        previous = current
    return previous[-1]


def character_error_rate(
    references: Iterable[Sequence[int]],
    hypotheses: Iterable[Sequence[int]],
) -> float:
    """Compute the corpus level CER as ``sum_edit / sum_reference_length``."""
    total_edits = 0
    total_length = 0
    for reference, hypothesis in zip(references, hypotheses):
        total_edits += _levenshtein(list(reference), list(hypothesis))
        total_length += max(len(reference), 1)
    return total_edits / max(total_length, 1)
